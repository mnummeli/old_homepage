/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

int is_bitboard_quadruple_consistent(Bitboard *straight,Bitboard *rotated,
	Bitboard *nw,Bitboard *ne);
char are_bitboards_consistent(Board *brd);
