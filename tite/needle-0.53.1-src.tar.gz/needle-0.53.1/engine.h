/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _ENGINE_H

/* Engine flag masks */

/* Computer white/black/none */
#define COMP_WHITE	(0x0001)
#define COMP_BLACK	(0x0002)

/* Clock type */
#define CONVENTIONAL	(0x0004)
#define INCREMENTAL	(0x0008)
#define STMOVE	(0x0010)

/* Allow pondering */
#define PONDER	(0x0020)

/* Post thinking */
#define POST	(0x0040)

/* Analyze mode on */
#define ANALYZE	(0x0080)

/* ICS client mode on */
#define ICS	(0x0100)

/* Currently pondering/thinking */
#define CURRENTLY_PONDERING	(0x0200)
#define CURRENTLY_THINKING	(0x0400)

/* Thinking or pondering should be halted NOW */
#define HALT	(0x0800)

/* Game is to be reset to start position */
#define DISPOSE	(0x1000)

/* Engine is to be terminated */
#define TERMINATE	(0x2000)

#define EXIT_THINKING_LOOP	(HALT|DISPOSE|TERMINATE)

struct chessclock_stc {
	int stopped;		/* TRUE if this clock is stopped */
	double last_start;	/* Latest time in seconds when this was started */
	double sl_last_start;	/* Seconds left in latest start or stop */
};

typedef struct chessclock_stc Chessclock;

struct engine_variables_stc {
	Notebook ntb;
	Zobtrace zt;
	Openingbook opb;
	Hashtable ht;
	Chessclock computers_clock;
	Chessclock opponents_clock;
	Chessclock this_move_clock;
	int positions_seen;
	int mps; /* mps moves in base time in CONVENTIONAL clock */
	int base;
	int inc; /* increment per move in INCREMENTAL clock */
	int st;  /* search time per move in STMOVE clock */
	int sd; /* Maximum depth */
	unsigned short flags; /* See above */
};

typedef struct engine_variables_stc Engine_variables;
