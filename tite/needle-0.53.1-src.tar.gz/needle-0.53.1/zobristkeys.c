/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _ZOBRISTKEYS_C

#include "needle.h"

void init_zobtrace(Zobtrace *zobtrace){
  int i;
  zobtrace->size=0;
  for(i=0;i<64;i++){
    zobtrace->zkeys[i].whole=BITBOARD_ZERO;
  }
}

/* A 64-bit random number generator for Zobrist keys */
long long rand64(void){
  return rand()^((long long)rand()<<15)^((long long)rand()<<30)^
    ((long long)rand()<<45)^((long long)rand()<<60);
}

void generate_keys(){
  int i;
  for(i=0;i<=0x3f;i++){
    zk.K[i].whole=rand64();
    zk.Q[i].whole=rand64();
    zk.B[i].whole=rand64();
    zk.N[i].whole=rand64();
    zk.R[i].whole=rand64();
    zk.P[i].whole=rand64();
    zk.k[i].whole=rand64();
    zk.q[i].whole=rand64();
    zk.b[i].whole=rand64();
    zk.n[i].whole=rand64();
    zk.r[i].whole=rand64();
    zk.p[i].whole=rand64();
  }
  zk.blacks_move.whole=rand64();
  for(i=0;i<=0xf;i++){
    zk.ep[i].whole=rand64();
  }
  for(i=0;i<=0x3;i++){
    zk.castle[i].whole=rand64();
  }
}

/* Test whether two Zobrist keys equal */
int zkequals(const Zobrist zk1, const Zobrist zk2){
	if((zk1.halves[0]==zk2.halves[0])&&
	(zk1.halves[1]==zk2.halves[1])){
		return TRUE;
	}
	return FALSE;
}
