/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#include <string.h>

/* Parse s into tokens separated by characters in delim.
 * Use ptrptr as an user allocated place to keep track of
 * scanning the string. As this routine is not available
 * in all versions of C library, it was re-written to
 * be used in this project also. */
char *n_strtok_r(char *s, const char *delim, char **ptrptr){
  char *token;
  if(s==NULL)
    s=*ptrptr;
  s+=strspn(s,delim);
  if(*s==0){
    *ptrptr=s;
    return NULL;
  }
  token=s;
  s = (char *) strpbrk(token,delim);
  if(s==NULL){
    *ptrptr=token;
    while(**ptrptr!=0){
      (*ptrptr)++;
    }
    return (char *) token;
  } else {
    *s=0;
    *ptrptr=s+1;
  }
  return (char *) token;
}
