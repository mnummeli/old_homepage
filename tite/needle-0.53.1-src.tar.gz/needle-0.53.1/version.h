/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define BASENAME     "Needle"
#define VERSION      "0.53"
#define EXTRAVERSION ".1"
 
