/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _MY_BSF_H

int my_bsf(unsigned long long arg);
