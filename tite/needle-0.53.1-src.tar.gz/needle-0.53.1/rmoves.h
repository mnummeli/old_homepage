/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _RMOVES_H

unsigned long long bpow(int arg);
const char *square_for_bit(int bitno);
int bit_for_square(const char *square);
int r_bit_for_bit(int bitno);
const char *r_square_for_bit(int bitno);
int r_bit_for_square(const char *square);
int nw_bit_for_bit(int bitno);
const char *nw_square_for_bit(int bitno);
int nw_bit_for_square(const char *square);
int ne_bit_for_bit(int bitno);
const char *ne_square_for_bit(int bitno);
int ne_bit_for_square(const char *square);
int rankno_for_bit(int bitno);
int fileno_for_bit(int bitno);
int nw_diano_for_bit(int bitno);
int nw_mask_for_bit(int bitno);
int ne_diano_for_bit(int bitno);
int ne_mask_for_bit(int bitno);

unsigned long long all_white_pieces_except_K(const Board *brd);
unsigned long long all_white_pieces_except_pawns(const Board *brd);
unsigned long long all_white_pieces(const Board *brd);
unsigned long long all_white_pieces_except_K_r(const Board *brd);
unsigned long long all_white_pieces_r(const Board *brd);
unsigned long long all_white_pieces_except_K_nw(const Board *brd);
unsigned long long all_white_pieces_nw(const Board *brd);
unsigned long long all_white_pieces_except_K_ne(const Board *brd);
unsigned long long all_white_pieces_ne(const Board *brd);

unsigned long long all_black_pieces_except_K(const Board *brd);
unsigned long long all_black_pieces_except_pawns(const Board *brd);
unsigned long long all_black_pieces(const Board *brd);
unsigned long long all_black_pieces_except_K_r(const Board *brd);
unsigned long long all_black_pieces_r(const Board *brd);
unsigned long long all_black_pieces_except_K_nw(const Board *brd);
unsigned long long all_black_pieces_nw(const Board *brd);
unsigned long long all_black_pieces_except_K_ne(const Board *brd);
unsigned long long all_black_pieces_ne(const Board *brd);

unsigned long long totally_all_pieces(const Board *brd);
unsigned long long totally_all_pieces_r(const Board *brd);
unsigned long long totally_all_pieces_nw(const Board *brd);
unsigned long long totally_all_pieces_ne(const Board *brd);
