/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _ZOBRISTKEYS_H

void init_zobtrace(Zobtrace *);
long long rand64(void);
void generate_keys(void);
int zkequals(const Zobrist, const Zobrist);
