/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _EVALUATE_H

int evaluate_and_pick_material(Board *brd, Piececalc *pc);
int evaluate_dm(Board *brd, Piececalc *pc);
int evaluate_king_safety(Board *brd, Piececalc *pc);
int evaluate_eg_king_safety(Board *brd, Piececalc *pc);
int evaluate_pawn_structure(Board *brd, Piececalc *pc);
int evaluate_eg_pawn_structure(Board *brd, Piececalc *pc);
int evaluate_for_midgame(Board *brd, Piececalc *pc);
int evaluate_for_endgame(Board *brd, Piececalc *pc);
int evaluate(Board *brd);
int evaluate_for_color(Board *brd);
void zero_piececalc(Piececalc *aop);
int white_piecevalues(Piececalc *aop);
int black_piecevalues(Piececalc *aop);

