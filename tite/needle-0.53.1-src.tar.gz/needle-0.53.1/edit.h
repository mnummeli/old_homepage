/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _EDIT_H

void replace_newline(char *s);
char testsquare(const Board *brd, const char *square);
void setsquare(Board *brd, const char *square, char new_content);
void resetsquare(Board *brd, const char *square, char old_content);
void setsafe(Board *brd, const char *square, char new_content);
void resetsafe(Board *brd, const char *square);
const char *test_castling_flags(Board *brd);
const char *get_ep_square(Board *brd);
void set_ep_square(Board *brd, char *epsquare);
void reset_ep_square(Board *brd);
void set_castling_flags(Board *brd, char *newcf);
void null_move(Board *brd);
void set_side_to_move(Board *brd, char whosmove);
void absolutely_clear_board(Board *brd);
void boardcpy(const Board *original_board, Board *new_board);
void numtostring(int number, char **ptrptr);
void appendtostring(const char *string_p, char **ptrptr);
void dump_bitboard_bits (Bitboard *bitboard);
void make_move(Board *brd, Move_node *mvn);
int make_move_from_list(Board *brd, Movelist *mvl, char *move);
void unmake_move(Board *brd, Move_node *mvn);
void import_fen(Board *brd, const char *fen_string);
void export_fen(Board *brd, char *fen_string);
void reset_board(Board *brd);
