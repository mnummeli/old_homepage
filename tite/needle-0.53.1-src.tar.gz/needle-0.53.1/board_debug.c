/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#include "needle.h"

int is_bitboard_quadruple_consistent(Bitboard *straight,
	Bitboard *rotated,
	Bitboard *nw,
	Bitboard *ne){
	int i,state_of_bit,state_of_r_bit,state_of_nw_bit,state_of_ne_bit;
	for(i=0;i<64;i++){
		state_of_bit=!!(straight->whole & bpow(i));
		state_of_r_bit=!!(rotated->whole & bpow(r_bit_for_bit(i)));
		state_of_nw_bit=!!(nw->whole & bpow(nw_bit_for_bit(i)));
		state_of_ne_bit=!!(ne->whole & bpow(ne_bit_for_bit(i)));
		if((state_of_bit!=state_of_r_bit)||
			(state_of_bit!=state_of_nw_bit)||
			(state_of_bit!=state_of_ne_bit)){
				return FALSE; /* Bitboards are inconsistent */
		}
	}
	return TRUE; /* Bitboards are consistent */
}

char are_bitboards_consistent(Board *brd) {
	int i;
	const char pieceorder[]="KQBNRPkqbnrp";
	Bitboard *bitboards_start_ptr;
	bitboards_start_ptr=&(brd->K);
	for(i=0;i<12;i++){
		if(!is_bitboard_quadruple_consistent(&(bitboards_start_ptr[i]),
			&(bitboards_start_ptr[i+12]),
			&(bitboards_start_ptr[i+24]),
			&(bitboards_start_ptr[i+36]))){
			return pieceorder[i];
		}
	}
	if(!is_bitboard_quadruple_consistent(&(brd->ep),
		&(brd->epr),
		&(brd->epnw),
		&(brd->epne))){
		return 'e';
	}
	return 0;
}
