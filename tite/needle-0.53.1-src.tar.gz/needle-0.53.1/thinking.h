/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _THINKING_H

void init_PVlist(PVlist *pvlist);
void copy_PVlist(PVlist *new_pvlist, PVlist *old_pvlist);
void print_PVlist(PVlist *principal_variation);
void print_movelist_moves(Movelist *mvl);
void reset_engine_variables();
void init_opening_book();
void free_opening_book();
char *get_move_from_book(Board *brd);
void alloc_hashtable(int lb_of_cluster_amount,int lb_of_cluster_size);
void clear_hashtable();
void free_hashtable();
void add_to_hashtable(Board *brd,
	char depth_until_bottom,
	unsigned char position_value_type,
	short position_value,
	char *suggested_move);
Lookup_node *find_from_hashtable(Board *brd);
Lookup_node *find_next_empty_from_hashtable(Board *brd);
int iterativedeep(Board *brd, int mdepth, char *best_move, PVlist *principal_variation);
int alpha_beta(Board *brd,int depth,int extension,int prev_alpha,int prev_beta,
	char *best_move, Movelist *pre_defined_list, Movelist *new_list_template,
	PVlist *principal_variation, int *is_reliable);
int qsearch(Board *brd,int depth,int prev_alpha,int prev_beta,
	char *best_move,PVlist *principal_variation);

