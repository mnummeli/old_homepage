/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _BOARD_H

#define BITBOARD_ZERO	((unsigned long long)(0x0000000000000000))
#define BITBOARD_UNIT	((unsigned long long)(0x0000000000000001))
#define TRUE		1
#define FALSE		0
#define OTHERCOLOR(COLOR)	('w'+'b'-(COLOR))

#define	QUEEN_VALUE	900
#define	ROOK_VALUE	500
#define	BISHOP_VALUE	300
#define	KNIGHT_VALUE	300
#define	PAWN_VALUE	100

#define EXACT_VALUE	1
#define LOWER_BOUND	2
#define UPPER_BOUND	3

#define WHITE_SQUARES_MASK (0x55aa55aa55aa55aa)
#define BLACK_SQUARES_MASK (0xaa55aa55aa55aa55)

union bitboard_uni {
	unsigned long long whole;
	unsigned long halves[2];
	unsigned char rows[8];
};

typedef union bitboard_uni Bitboard;
typedef union bitboard_uni Zobrist;

struct zobtrace_stc {
	int size;
	Zobrist zkeys[64];
};

typedef struct zobtrace_stc Zobtrace;

struct zkeyset_stc {

	/* These are piece zobrist keys. <piece>[0] stands for h1,
	 * <piece>[0x3f] stands for a8 */
	Zobrist K[0x40];
	Zobrist Q[0x40];
	Zobrist B[0x40];
	Zobrist N[0x40];
	Zobrist R[0x40];
	Zobrist P[0x40];
	Zobrist k[0x40];
	Zobrist q[0x40];
	Zobrist b[0x40];
	Zobrist n[0x40];
	Zobrist r[0x40];
	Zobrist p[0x40];

	/* This is XOR'ed if it is black's move */
	Zobrist blacks_move;

	/* These are en passant squares. ep[0] stands for h3, ep[0xf] for a6 */
	Zobrist ep[0x10];

	/* castle[0] ==> K castling
	 * castle[1] ==> Q castling
	 * castle[2] ==> k castling
	 * castle[3] ==> q castling */
  	Zobrist castle[0x4];

};

typedef struct zkeyset_stc ZKeySet;

struct move_node_stc {
	char moving_piece;
	char move[6];
	char captured_piece;
	int  approx_move_value;
};

typedef struct move_node_stc Move_node;

struct movelist_stc {
	int size;
	Move_node moves[1024];
};

typedef struct movelist_stc Movelist;

struct position_node_stc {
	char fen[128];
	Zobrist z;
	char move_made[6];
};

typedef struct position_node_stc Position_node;

struct pvlist_stc {
	int size;
	char moves[64][6];
};

typedef struct pvlist_stc PVlist;

/* This is the 'notebook', max 2048 positions / 1024 moves.
 * Position numbers are computed: (<move number>-1)*2+color
 * where 0=white, 1=black */
struct notebook_stc {
	Position_node positions[2048];
	int current_position;
	int last_position;
};

typedef struct notebook_stc Notebook;

struct book_node_stc {
	Zobrist z;
	int number_of_moves;
	char *moves;
};

typedef struct book_node_stc Book_node;

struct openingbook_stc {
	int number_of_positions;
	Book_node *positions;
};

typedef struct openingbook_stc Openingbook;

struct lookup_node_stc {
	Zobrist z;
	char depth_until_bottom;
	unsigned char position_value_type;
	short position_value;
	char suggested_move[6];
};

typedef struct lookup_node_stc Lookup_node;

struct lookup_cluster_stc {
	int lb_of_cluster_size;
	Lookup_node *nodes;
	int next_insert;
};

typedef struct lookup_cluster_stc Lookup_cluster;

struct hashtable_stc {
	int lb_of_cluster_amount;
	Lookup_cluster *clusters;
};

typedef struct hashtable_stc Hashtable;

struct piececalc_stc {

	/* How many of each piece there are? */
	int Q,B,N,R,P;
	int q,b,n,r,p;

	/* Where they are? h1=0, g1=1 etc. */
	unsigned char Ksq,Qsq[9],Bsq[10],Nsq[10],Rsq[10],Psq[8];
	unsigned char ksq,qsq[9],bsq[10],nsq[10],rsq[10],psq[8];
};

typedef struct piececalc_stc Piececalc;

struct board_stc {

	Zobrist key;	/* Key of this position */
	char whosmove;	/* The player on move, w or b */
	int half_moves;	/* Half moves since last capture/pawn move */
	int full_moves;	/* Full moves count since start of the game */

	/* Pieces on a straight bitboard where h1 is lowest,
	 * g1 second-lowest and a8 highest bit */
	Bitboard K,Q,B,N,R,P; /* White */
	Bitboard k,q,b,n,r,p; /* Black */

	/* Pieces on a rotated bitboard where a1 is lowest,
	 * a2 second-lowest and h8 highest bit */
	Bitboard Kr,Qr,Br,Nr,Rr,Pr; /* White */
	Bitboard kr,qr,br,nr,rr,pr; /* Black */

	/* Pieces on a rotated bitboard where h1 is lowest,
	 * g2 second-lowest, b6 second-highest and a7 highest
	 * bit */
	Bitboard Knw,Qnw,Bnw,Nnw,Rnw,Pnw; /* White */
	Bitboard knw,qnw,bnw,nnw,rnw,pnw; /* Black */

	/* Pieces on a rotated bitboard where h1 is lowest,
	 * b8 second-lowest, b2 second-highest and a1 highest
	 * bit */
	Bitboard Kne,Qne,Bne,Nne,Rne,Pne; /* White */
	Bitboard kne,qne,bne,nne,rne,pne; /* Black */

	/* Same for en-passant-squares */
	Bitboard ep,epr,epnw,epne;

	/* Castling flags:
	 *
	 * ----qkQK
	 * 76543210
	 */
	unsigned char castling_flags;
};

typedef struct board_stc Board;

