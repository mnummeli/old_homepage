/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _MAIN_C

#include "needle.h"

void console(void);
void xboardclient(void);

#ifdef DEBUG
FILE *errlog;
#endif

int main(int argc, char *argv[]){
	char startcmd[128];
	srand(iclock());
	generate_keys();
	
#ifdef DEBUG
	errlog=fopen("needle.err","wb");
#endif
	
	fgets(startcmd,127,stdin);
	if(!memcmp(startcmd,"xboard",6)){
		xboardclient();
	} else {
		console();
	}
#ifdef DEBUG
	fclose(errlog);
#endif
	return 0;
}

#undef _MAIN_C
