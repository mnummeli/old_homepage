/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _CHESSCLOCK_H

double dclock(void);
int iclock(void);
double time_left(double,double);
double time_left_in_clock(Chessclock *);
void stop_clock(Chessclock *clock);
void start_clock(Chessclock *clock);
void set_clock(Chessclock *clock,double);
void addtime(Chessclock *clock,double);
