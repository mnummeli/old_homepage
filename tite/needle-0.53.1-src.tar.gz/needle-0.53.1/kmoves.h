/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _KMOVES_H

unsigned long long kmask_for_bit(int bitnumber);
unsigned long long kmask_for_square(char *square);
unsigned long long smask_for_bit(int bitnumber);
unsigned long long smask_for_square(char *square);
