/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _GLOBAL_VARIABLES_H

#ifndef _MAIN_C
extern
#endif
ZKeySet zk;

#ifndef _MAIN_C
extern
#endif
Engine_variables evars;
