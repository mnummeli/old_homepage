/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _NMOVES_H

unsigned long long nmask_for_bit(int bitnumber);
unsigned long long nmask_for_square(char *square);
