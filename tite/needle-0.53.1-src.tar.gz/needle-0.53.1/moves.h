/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _MOVES_H

void push_move(Movelist *mvl, const char moving_piece, const char *original_square,
	const char *destination_square, const char captured_piece);
int is_threat(const Board *brd, char whosmove, int bitno);
void generate_promotions(Board *brd, Movelist *mvl);
void kthreats_to(const Board *brd, Movelist *mvl, char whosmove, int bitno);
void nthreats_to(const Board *brd, Movelist *mvl, char whosmove, int bitno);
void pthreats_to(const Board *brd, Movelist *mvl, char whosmove,
	int bitno, int pawnmovestyle);
void rqthreats_to(const Board *brd, Movelist *mvl, char whosmove, int bitno);
void bqthreats_to(const Board *brd, Movelist *mvl, char whosmove, int bitno);
void threats_to(const Board *brd, Movelist *mvl, char whosmove,
	int bitno, int pawnmovestyle);
void generate_captures(Board *brd, Movelist *mvl);
void generate_quiet_moves(Board *brd, Movelist *mvl);
void generate_moves(Board *brd, Movelist *mvl);
void generate_nonquiescent_moves(Board *brd, Movelist *mvl);
void generate_check_evasions(Board *brd, Movelist *mvl);
void movelistcpy(Movelist *old, Movelist *new);
void construct_legal_movelist(Board *brd, Movelist *pseudo_legal, Movelist *legal);
void init_notebook(Notebook *ntb);
void write_position(Board *brd, Notebook *ntb);
void write_move(Notebook *ntb, char *move);
void get_current_position(Board *brd, Notebook *ntb);
void reverse(Board *brd, Notebook *ntb, int moves);
void forward(Board *brd, Notebook *ntb, int moves);
void print_notebook_contents(Notebook *ntb);
int is_check(Board *brd);
int is_illegal(Board *brd);
int is_mate(Board *brd, Movelist *mvl);
int is_threefold_repetition(Notebook *ntb, Zobtrace *zt, int half_moves);
int compare_move_values(const void *first_move, const void *second_move);
