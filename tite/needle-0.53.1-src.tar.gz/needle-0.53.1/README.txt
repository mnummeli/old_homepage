Needle - a bitboard based chess engine


Licence agreement

This is Needle, a freeware Winboard-compatible chess engine. You may freely 
share (without fee) unmodified copies of either it's source or binary 
executable, but not change it nor sell it without written permission from the 
author, Mikko Nummelin. There is ABSOLUTELY NO WARRANTY for this program, not 
for any possible software or hardware damages it may cause, nor for fitness for 
any particular purpose. Suggestions and bugfixes may be mailed to the author to 
address mnummeli_AT_cc._NOSPAM_hut.fi (replace _AT_ with '@' and remove 
_NOSPAM_).

All rights reserved except otherwise indicated on this Licence. 
(c) 2004, Mikko Nummelin 


Installation instructions

U**X

To compile in U**X-systems with GCC: 

$ make clean; make

$ cp needle needle.bk <directory from where you run xboard with Needle>

To run in U**X-systems with xboard: 

$ xboard -fcp needle -size Small -tc 5 -inc 10 &

Size, time control and increment are just examples, Needle accepts all time 
control types. 

Microsoft Windows

To compile in Microsoft Windows-systems with MSYS/MinGW (Cygwin might also work 
but is not tested): 

$ make clean; make mswindows=1

$ cp needle.exe needle.bk <Your WinBoard directory>

To run in Microsoft Windows-systems with WinBoard: 

Edit winboard.ini and add needle.exe to sections /firstChessProgramNames and 
/secondChessProgramNames. 
