/******************************************
* Needle - a bitboard based chess engine. *
* (C) 2004 Mikko Nummelin                 *
******************************************/

#define _NEEDLE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/time.h>

#include "board.h"
#include "board_debug.h"
#include "engine.h"
#include "edit.h"
#include "my_bsf.h"
#include "rmoves.h"
#include "kmoves.h"
#include "nmoves.h"
#include "moves.h"
#include "zobristkeys.h"
#include "evaluate.h"
#include "thinking.h"
#include "chessclock.h"
#include "global_variables.h"
