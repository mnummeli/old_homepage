#ifndef OPNAME_H
#define OPNAME_H
#include "z80_type.h"

#ifdef __cplusplus
extern "C" {
#endif

extern char *opname(byte *mem, dbyte pc, dbyte *endop);

#ifdef __cplusplus
}
#endif

#

#endif /* OPNAME_H */
