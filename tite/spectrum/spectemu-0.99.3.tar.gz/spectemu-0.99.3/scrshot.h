#ifndef SCRSHOT_H
#define SCRSHOT_H

#define SCRSHOT_SCR 0

extern void save_screenshot_file(char *name);
extern void save_screenshot(void);

#endif /* SCRSHOT_H */
