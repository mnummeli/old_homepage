/*
 * Z80 disassembler
 *
 * zdisasm.c
 * (C) Mikko Nummelin 2002
 */

#include "z80_disasm.h"
#include "zdisasm.h"
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv){
  int i,count;
  char tmpstr[5];
  char filename[MAX_FILENAME_LENGTH];
  FILE *ifile;
  char cmdline_prompt[16],ignore_prompt[16];
  unsigned char virtual_addr_str[5];
  char cmd_str[17];
  char instcode_str[9];

  /* Initialization of certain values. */
  strncpy(filename,"TMP.MEM",8);
  vmem.start  = 0x0000;
  vmem.offset = 0;
  for(i=0;i<0x10000;i++){
    vmem.mempage[i]=0x00;
  }

  /* Parsing command line arguments */
  for(i=0;i<argc;i++){
    if((argc==1)||!strcmp(argv[i],"-h")){
      printf("Usage:\n");
      printf("$ zdisasm -m <start address in hex> -if <filename>\n");
      return 0;
    }
    if(!strcmp(argv[i],"-if")){
      i++;
      if(i<argc){
	strncpy(filename,argv[i],MAX_FILENAME_LENGTH-1);
	printf("zdisasm: Reading from %s\n",filename);
      }
      continue;
    }
    if(!strcmp(argv[i],"-m")){
      i++;
      if(i<argc){
	strncpy(tmpstr,argv[i],5);
	vmem.start = hex_to_dec(tmpstr);
	printf("zdisasm: Virtual memory starts from %4X\n",vmem.start);
      }
      continue;
    }
  }

  ifile=fopen(filename,"rb");

  if(ifile==NULL){
    fprintf(stderr,"zdisasm: Error opening file %s\n",filename);
    return 0;
  }

  fread(vmem.mempage,sizeof(char),0x10000,ifile);
  fclose(ifile);

  printf("> ");
  fgets(cmdline_prompt,16,stdin);
  while(cmdline_prompt[0]!='q'){

    /* Help */  
    if(cmdline_prompt[0]=='h'){
      printf("Available commands:\n");
      printf("q - quit\n");
      printf("m <address in hex> - Moves pointer to address.\n");
      printf("l <number> - Lists n commands.\n");
    }

    /* Changes point from which to list commands. */
    if(cmdline_prompt[0]=='m'){
      sscanf(cmdline_prompt,"%s %s",ignore_prompt,tmpstr);
      vmem.offset=hex_to_dec(tmpstr);
      vmem.offset-=vmem.start;
      printf("zdisasm: Pointer moved to %4X\n",vmem.start+vmem.offset);
    }

    if(cmdline_prompt[0]=='l'){
      sscanf(cmdline_prompt,"%s %d",ignore_prompt,&count);
      printf("zdisasm: Listing %d instructions ...\n",count);
      for(i=0;i<count;i++){
	vmem.offset+=
	  disasm_normal_opcode(&vmem.mempage[vmem.offset],
			       vmem.start+vmem.offset,
			       virtual_addr_str,
			       cmd_str,
			       instcode_str);
	printf("%-4s %-16s %-8s\n",virtual_addr_str,cmd_str,instcode_str);
      }
    }

    printf("> ");
    fgets(cmdline_prompt,16,stdin);
  }

  printf("zdisasm: Program finished successfully.\n");
  return 0;
}
