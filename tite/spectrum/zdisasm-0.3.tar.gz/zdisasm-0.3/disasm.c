/*
 * Z80 disassembler
 *
 * disasm.c
 * (C) Mikko Nummelin 2002
 */

#undef PREFIXED_Z80_INSTRUCTIONS

#include "z80_disasm.h"
#include "disasm.h"
#include <stdio.h>
#include <string.h>

/*
 * Disassembles the next Z80 opcode from place pointed by
 * actual memory address. Virtual memory address is used
 * for annotations and jump references, because we usually
 * need such a memory space for example when looking at
 * Spectrum emulator programs. In that case the virtual
 * memory address is the pointer to Spectrum memory space.
 * This disassembler can, however, be used also as part of
 * other Z80 based applications also.
 * Returned values are virtual address in hex value, which
 * needs to be reserved by YOU to contain AT LEAST 5 bytes,
 * Command string, which needs to be reserved by YOU to contain
 * AT LEAST 17 bytes, and finally Hex-instruction string, which
 * needs to have at least 9 bytes. Failing to comply with these
 * instructions may result in crash/Segmentation fault, etc. ugly
 * consequences.
 * This function returns the amount of bytes parsed.
 */
int disasm_normal_opcode
(unsigned char *actual_addr,      /* -> Actual memory address   */
 unsigned int  virtual_addr,      /* -> Virtual memory address  */
 unsigned char *virtual_addr_str, /* <- Virtual address in hex  */
 char          *cmd_str,          /* <- Command string          */
 unsigned char *instcode_str)     /* <- Hex-instructions string */
{
  register int i;
  unsigned int va,cmd_length;
  unsigned char *read_ptr;
  char hbyte_1[3];
  char hbyte_2[3];
  char *tmp,*tmp_reg_1,*tmp_reg_2;
  char reg_txt_1[8];
  char reg_txt_2[8];

  /* Some error checks */
  if(actual_addr==NULL){
    fprintf(stderr, "Disasm-normal-opcode: Actual memory address not specified.\n");
    return FALSE;
  }
  if(virtual_addr_str==NULL){
    fprintf(stderr, "Disasm-normal-opcode: Virtual memory address string not specified.\n");
    return FALSE;
  }
  if(cmd_str==NULL){
    fprintf(stderr, "Disasm-normal-opcode: Command string not specified.\n");
    return FALSE;
  }
  if(instcode_str==NULL){
    fprintf(stderr, "Disasm-normal-opcode: Hex-instructions string not specified.\n");
    return FALSE;
  }

  /* Only bits 0-15 are used from virtual address! */
  va = virtual_addr&0xFFFF;

  /* Initializes virtual address string empty */
  for(i=0;i<VIRTUAL_ADDR_STR_SIZE;i++){ virtual_addr_str[i]=0; }

  /* Initializes command string empty */
  for(i=0;i<CMD_STR_SIZE;i++){ cmd_str[i]=0; }

  /* Initializes hex-instructions string empty */
  for(i=0;i<HEXINST_STR_SIZE;i++){ instcode_str[i]=0; }

  read_ptr   = actual_addr;
  cmd_length = 0;

  fl.ix_on       = FALSE;
  fl.iy_on       = FALSE;
  fl.cb_resolved = TRUE;
  fl.ed_resolved = TRUE;

  dec_to_hex_4(va,virtual_addr_str);
  append_code(read_ptr[0],instcode_str);

  /* Check whether there is need for IX register pair */
  if(read_ptr[0]==0xDD){
    fl.ix_on=TRUE;
    cmd_length++;
    read_ptr++;
    append_code(read_ptr[0],instcode_str);
  }

  /* Check whether there is need for IY register pair */
  if(read_ptr[0]==0xFD){
    fl.iy_on=TRUE;
    cmd_length++;
    read_ptr++;
    append_code(read_ptr[0],instcode_str);
  }

  if(read_ptr[0]==0xCB){
    cmd_length++;
    read_ptr++;
    append_code(read_ptr[0],instcode_str);
    
    /* Handle prefix CB here */
    disasm_cb_opcode(read_ptr,cmd_str);

    if(fl.ix_on || fl.iy_on){
      fprintf(stderr,"Disasm-normal-opcode: Unsupported index register combination with prefix CBh.\n"); 
    }

    if(fl.cb_resolved==FALSE){
      fprintf(stderr,"Disasm-normal-opcode: Prefix CBh not resolved.\n"); 
    } else {
      return cmd_length;
    }
  }

  if(read_ptr[0]==0xED){
    cmd_length++;
    read_ptr++;
    append_code(read_ptr[0],instcode_str);
    
    /* Handle prefix ED here ... */
    cmd_length+=disasm_ed_opcode(read_ptr,cmd_str,instcode_str);

    if(fl.ed_resolved==FALSE){
      fprintf(stderr,"Disasm-normal-opcode: Prefix ED not resolved.\n"); 
    } else {
      return cmd_length;
    }
  }

  switch(read_ptr[0]){

    /* 00h : NOP */
  case 0x00:
    cmd_length++;
    sprintf(cmd_str,"nop");
    return cmd_length;

    /* 02h : LD (BC),A */
  case 0x02:
    cmd_length++;
    sprintf(cmd_str,"ld (bc),a");
    return cmd_length;

    /* 08h : EX AF,AF' */
  case 0x08:
    cmd_length++;
    sprintf(cmd_str,"ex af,af'");
    return cmd_length;

    /* 0Ah : LD A,(BC) */
  case 0x0a:
    cmd_length++;
    sprintf(cmd_str,"ld a,(bc)");
    return cmd_length;

    /* 10h : DJNZ dis */
  case 0x10:
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    sprintf(cmd_str,"djnz %s",hbyte_1);
    return cmd_length;

    /* 12h : LD (DE),A */
  case 0x12:
    cmd_length++;
    sprintf(cmd_str,"ld (de),a");
    return cmd_length;

    /* 18h : JR dis */
  case 0x18:
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    sprintf(cmd_str,"jr %s",hbyte_1);
    return cmd_length;

    /* OUT/IN (address),a */
  case 0xD3:
  case 0xDB:
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    if(read_ptr[0]==0xD3){
      sprintf(cmd_str,"out (%s),a",hbyte_1);
    } else {
      sprintf(cmd_str,"in (%s),a",hbyte_1);
    }
    return cmd_length;
    
    /* 1Ah : LD A,(DE) */
  case 0x1a:
    cmd_length++;
    sprintf(cmd_str,"ld a,(de)");
    return cmd_length;

    /* 76h : HALT */
  case 0x76:
    cmd_length++;
    sprintf(cmd_str,"halt");
    return cmd_length;

  case 0xE3:
    cmd_length++;
    if(fl.ix_on){
      sprintf(cmd_str,"ex (sp),ix");
    } else if(fl.iy_on){
      sprintf(cmd_str,"ex (sp),iy");
    } else {
      sprintf(cmd_str,"ex (sp),hl");
    }
    return cmd_length;

  case 0xF9:
    cmd_length++;
    if(fl.ix_on){
      sprintf(cmd_str,"ld sp,ix");
    } else if(fl.iy_on){
      sprintf(cmd_str,"ld sp,iy");
    } else {
      sprintf(cmd_str,"ld sp,hl");
    }
    return cmd_length;
    
  case 0xEB:
    cmd_length++;
    if(fl.ix_on){
      sprintf(cmd_str,"ex de,ix");
    } else if(fl.iy_on){
      sprintf(cmd_str,"ex de,iy");
    } else {
      sprintf(cmd_str,"ex de,hl");
    }
    return cmd_length;

  case 0xF3:
    cmd_length++;
    sprintf(cmd_str,"di");
    return cmd_length;

  case 0xC9:
    cmd_length++;
    sprintf(cmd_str,"ret");
    return cmd_length;

  case 0xD9:
    cmd_length++;
    sprintf(cmd_str,"exx");
    return cmd_length;

  case 0xFB:
    cmd_length++;
    sprintf(cmd_str,"ei");
    return cmd_length;

  case 0xE9:
    cmd_length++;
    if(fl.ix_on){
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      sprintf(cmd_str,"jp(ix+%s)",hbyte_1);
    } else if(fl.iy_on){
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      sprintf(cmd_str,"jp(iy+%s)",hbyte_1);
    } else {
      sprintf(cmd_str,"jp(hl)");
    }
    return cmd_length;
  }

  /* JR flag,dis */
  if((read_ptr[0]&0xE7)==0x20){
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    sprintf(cmd_str,"jr %s,%s",
	    flags[(read_ptr[0]&0x18)>>3],hbyte_1);
    return cmd_length;
  }

  /* JP/CALL address */
  if((read_ptr[0]==0xC3)||
     (read_ptr[0]==0xCD)){
    cmd_length++;
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    (read_ptr[0]==0xC3) ?
      sprintf(cmd_str,"jp %s%s"  ,hbyte_2,hbyte_1) :
      sprintf(cmd_str,"call %s%s",hbyte_2,hbyte_1);
    return cmd_length;
  }

  /* JP/CALL flag,address */
  if(((read_ptr[0]&0xC7)==0xC2)||
     ((read_ptr[0]&0xC7)==0xC4)){
    cmd_length++;
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    ((read_ptr[0]&0x06)==0x02) ?
      sprintf(cmd_str,"jp %s,%s%s",
	      flags[(read_ptr[0]&0x38)>>3],hbyte_2,hbyte_1) :
      sprintf(cmd_str,"call %s,%s%s",
	      flags[(read_ptr[0]&0x38)>>3],hbyte_2,hbyte_1);
    return cmd_length;
  }

  /* LD register pair,NN */
  if((read_ptr[0]&0xCF)==0x01){
    cmd_length++;
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    if(fl.ix_on && (read_ptr[0]==0x21)){
      sprintf(cmd_str,"ld ix,%s%s",hbyte_2,hbyte_1);
    } else if(fl.iy_on && (read_ptr[0]==0x21)){
      sprintf(cmd_str,"ld iy,%s%s",hbyte_2,hbyte_1);
    } else {
      sprintf(cmd_str,"ld %s,%s%s",
	      regpairs_a[(read_ptr[0]&0x30)>>4],hbyte_2,hbyte_1);
    }
    return cmd_length;
  }

  /* LD (NN),HL */
  if(read_ptr[0]==0x22){
    cmd_length++;
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    if(fl.ix_on){
      sprintf(cmd_str,"ld (%s%s),ix",hbyte_2,hbyte_1);
    } else if(fl.iy_on){
      sprintf(cmd_str,"ld (%s%s),iy",hbyte_2,hbyte_1);
    } else {
      sprintf(cmd_str,"ld (%s%s),hl",hbyte_2,hbyte_1);
    }
    return cmd_length;
  }

  /* LD HL,(NN) */
  if(read_ptr[0]==0x2a){
    cmd_length++;
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    if(fl.ix_on){
      sprintf(cmd_str,"ld ix,(%s%s)",hbyte_2,hbyte_1);
    } else if(fl.iy_on){
      sprintf(cmd_str,"ld iy,(%s%s)",hbyte_2,hbyte_1);
    } else {
      sprintf(cmd_str,"ld hl,(%s%s)",hbyte_2,hbyte_1);
    }
    return cmd_length; 
  }

  /* LD (NN),A */
  if(read_ptr[0]==0x32){
    cmd_length++;
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    sprintf(cmd_str,"ld (%s%s),a",hbyte_2,hbyte_1);
    return cmd_length;
  }

  /* LD A,(NN) */
  if(read_ptr[0]==0x3a){
    cmd_length++;
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    sprintf(cmd_str,"ld a,(%s%s)",hbyte_2,hbyte_1);
    return cmd_length;
  }

  /* INC/DEC register-pair */
  if((read_ptr[0]&0xC7)==0x03){
    cmd_length++;
    if(fl.ix_on && ((read_ptr[0]&0xf7)==0x23)){
      (BITMASK(3)&read_ptr[0]) ?
	sprintf(cmd_str,"dec ix") :
	sprintf(cmd_str,"inc ix");
    } else if(fl.iy_on && ((read_ptr[0]&0xf7)==0x23)){
      (BITMASK(3)&read_ptr[0]) ?
	sprintf(cmd_str,"dec iy") :
	sprintf(cmd_str,"inc iy");
    } else {
      (BITMASK(3)&read_ptr[0]) ?
	sprintf(cmd_str,"dec %s",regpairs_a[(read_ptr[0]&0x30)>>4]) :
	sprintf(cmd_str,"inc %s",regpairs_a[(read_ptr[0]&0x30)>>4]);
    }
    return cmd_length;
  }

  /* PUSH/POP register-pair */
  if((read_ptr[0]&0xCB)==0xC1){
    cmd_length++;
    if(fl.ix_on && ((read_ptr[0]&0xFB)==0xE1)){
      (BITMASK(3)&read_ptr[0]) ?
	sprintf(cmd_str,"push ix") :
	sprintf(cmd_str,"pop ix");
    } else if(fl.iy_on && ((read_ptr[0]&0xFB)==0xE1)){
      (BITMASK(3)&read_ptr[0]) ?
	sprintf(cmd_str,"push iy") :
	sprintf(cmd_str,"pop iy");
    } else {
      (BITMASK(3)&read_ptr[0]) ?
	sprintf(cmd_str,"push %s",regpairs_b[(read_ptr[0]&0x30)>>4]) :
	sprintf(cmd_str,"pop %s",regpairs_b[(read_ptr[0]&0x30)>>4]);
    }
    return cmd_length;
  }

  if((read_ptr[0]&0xC6)==0x04){
    cmd_length++;
    if(fl.ix_on && (read_ptr[0]==0x34)){
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      (BITMASK(0)&read_ptr[0]) ?
	sprintf(cmd_str,"dec (ix+%s)",hbyte_1) :
	sprintf(cmd_str,"inc (ix+%s)",hbyte_1);
    } else if(fl.iy_on && (read_ptr[0]==0x34)){
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      (BITMASK(0)&read_ptr[0]) ?
	sprintf(cmd_str,"dec (iy+%s)",hbyte_1) :
	sprintf(cmd_str,"inc (iy+%s)",hbyte_1);
    } else if(fl.ix_on && ((read_ptr[0]&0xf6)==0x24)) {
      switch(read_ptr[0]&0x09){
      case 0x00:
	sprintf(cmd_str,"inc ixh");
	break;
      case 0x01:
	sprintf(cmd_str,"dec ixh");
	break;
      case 0x08:
	sprintf(cmd_str,"inc ixl");
	break;
      case 0x09:
	sprintf(cmd_str,"dec ixl");
	break;
      }
    } else if(fl.iy_on && ((read_ptr[0]&0xf6)==0x24)) {
      switch(read_ptr[0]&0x09){
      case 0x00:
	sprintf(cmd_str,"inc iyh");
	break;
      case 0x01:
	sprintf(cmd_str,"dec iyh");
	break;
      case 0x08:
	sprintf(cmd_str,"inc iyl");
	break;
      case 0x09:
	sprintf(cmd_str,"dec iyl");
	break;
      }
    } else {
      (BITMASK(0)&read_ptr[0]) ?
	sprintf(cmd_str,"dec %s",regs[(read_ptr[0]&0x38)>>3]) :
	sprintf(cmd_str,"inc %s",regs[(read_ptr[0]&0x38)>>3]);
    }
    return cmd_length;
  }

  if((read_ptr[0]&0xC7)==0x06){
    cmd_length++;
    if(fl.ix_on && (read_ptr[0]==0x36)){
      cmd_length++;
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      append_code(read_ptr[2],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      dec_to_hex_2(read_ptr[2],hbyte_2);
      sprintf(cmd_str,"ld (ix+%s),%s",hbyte_1,hbyte_2);
    } else if(fl.iy_on && (read_ptr[0]==0x36)){
      cmd_length++;
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      append_code(read_ptr[2],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      dec_to_hex_2(read_ptr[2],hbyte_2);
      sprintf(cmd_str,"ld (iy+%s),%s",hbyte_1,hbyte_2);
    } else if(fl.ix_on && ((read_ptr[0]&0xF7)==0x26)) {
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      switch(read_ptr[0]&0x08){
      case 0x00:
	sprintf(cmd_str,"ld ixh,%s",hbyte_1);
	break;
      case 0x08:
	sprintf(cmd_str,"ld ixl,%s",hbyte_1);
	break;
      }
    } else if(fl.iy_on && ((read_ptr[0]&0xF7)==0x26)) {
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      switch(read_ptr[0]&0x08){
      case 0x00:
	sprintf(cmd_str,"ld iyh,%s",hbyte_1);
	break;
      case 0x08:
	sprintf(cmd_str,"ld iyl,%s",hbyte_1);
	break;
      }
    } else {
      cmd_length++;
      append_code(read_ptr[1],instcode_str);
      dec_to_hex_2(read_ptr[1],hbyte_1);
      sprintf(cmd_str,"ld %s,%s",regs[(read_ptr[0]&0x38)>>3],hbyte_1);
    }
    return cmd_length;
  }

  if((read_ptr[0]&0xCF)==0x09){
    cmd_length++;
    tmp=regpairs_a[(read_ptr[0]&0x30)>>4];
    if(fl.ix_on){
      if(strcmp(tmp,"hl")==0){
	sprintf(cmd_str,"add ix,ix");
      } else {
	sprintf(cmd_str,"add ix,%s",tmp);
      }
    } else if(fl.iy_on){
      if(strcmp(tmp,"hl")==0){
	sprintf(cmd_str,"add iy,iy");
      } else {
	sprintf(cmd_str,"add iy,%s",tmp);
      }
    } else {
      sprintf(cmd_str,"add hl,%s",tmp);
    }
    return cmd_length;
  }

  if((read_ptr[0]&0xC7)==0x07){
    cmd_length++;
    sprintf(cmd_str,"%s",misc_cmds[(read_ptr[0]&0x38)>>3]);
    return cmd_length;
  }

  /* LD register,register */
  if((read_ptr[0]&0xC0)==0x40){

    cmd_length++;

    /* Obtains pointers to registers and register name
       strings in order to form the LD-statement. */
    tmp_reg_1 = regs[(read_ptr[0]&0x38)>>3];
    tmp_reg_2 = regs[read_ptr[0]&0x07];
    strcpy(reg_txt_1,tmp_reg_1);
    strcpy(reg_txt_2,tmp_reg_2);

    if(fl.ix_on){
      if(strcmp(reg_txt_1,"h")==0){
	strcpy(reg_txt_1,"ixh");
      }
      if(strcmp(reg_txt_1,"l")==0){
	strcpy(reg_txt_1,"ixl");
      }
      if(strcmp(reg_txt_2,"h")==0){
	strcpy(reg_txt_2,"ixh");
      }
      if(strcmp(reg_txt_2,"l")==0){
	strcpy(reg_txt_2,"ixl");
      }
      if(strcmp(reg_txt_1,"(hl)")==0){
	cmd_length++;
	append_code(read_ptr[1],instcode_str);
	dec_to_hex_2(read_ptr[1],hbyte_1);
	reg_txt_1[0]=0;
	sprintf(reg_txt_1,"(ix+%s)",hbyte_1);
      }
      if(strcmp(reg_txt_2,"(hl)")==0){
	cmd_length++;
	append_code(read_ptr[1],instcode_str);
	dec_to_hex_2(read_ptr[1],hbyte_1);
	reg_txt_2[0]=0;
	sprintf(reg_txt_2,"(ix+%s)",hbyte_1);
      }
    } else if(fl.iy_on){
      if(strcmp(reg_txt_1,"h")==0){
	strcpy(reg_txt_1,"iyh");
      }
      if(strcmp(reg_txt_1,"l")==0){
	strcpy(reg_txt_1,"iyl");
      }
      if(strcmp(reg_txt_2,"h")==0){
	strcpy(reg_txt_2,"iyh");
      }
      if(strcmp(reg_txt_2,"l")==0){
	strcpy(reg_txt_2,"iyl");
      }
      if(strcmp(reg_txt_1,"(hl)")==0){
	cmd_length++;
	append_code(read_ptr[1],instcode_str);
	dec_to_hex_2(read_ptr[1],hbyte_1);
	reg_txt_1[0]=0;
	sprintf(reg_txt_1,"(iy+%s)",hbyte_1);
      }
      if(strcmp(reg_txt_2,"(hl)")==0){
	cmd_length++;
	append_code(read_ptr[1],instcode_str);
	dec_to_hex_2(read_ptr[1],hbyte_1);
	reg_txt_2[0]=0;
	sprintf(reg_txt_2,"(iy+%s)",hbyte_1);
      }
    }
    sprintf(cmd_str,"ld %s,%s",reg_txt_1,reg_txt_2);
    return cmd_length;
  }

  /* Logical commands with register A */
  if((read_ptr[0]&0xC0)==0x80){

    cmd_length++;

    /* Obtains pointers to registers and register name
       strings in order to form the LD-statement. */
    tmp = logical_cmds[(read_ptr[0]&0x38)>>3];
    tmp_reg_2 = regs[read_ptr[0]&0x07];
    strcpy(reg_txt_2,tmp_reg_2);

    if(fl.ix_on){
      if(strcmp(reg_txt_2,"h")==0){
	strcpy(reg_txt_2,"ixh");
      }
      if(strcmp(reg_txt_2,"l")==0){
	strcpy(reg_txt_2,"ixl");
      }
      if(strcmp(reg_txt_2,"(hl)")==0){
	cmd_length++;
	append_code(read_ptr[1],instcode_str);
	dec_to_hex_2(read_ptr[1],hbyte_1);
	reg_txt_2[0]=0;
	sprintf(reg_txt_2,"(ix+%s)",hbyte_1);
      }
    } else if(fl.iy_on){
      if(strcmp(reg_txt_2,"h")==0){
	strcpy(reg_txt_2,"iyh");
      }
      if(strcmp(reg_txt_2,"l")==0){
	strcpy(reg_txt_2,"iyl");
      }
      if(strcmp(reg_txt_2,"(hl)")==0){
	cmd_length++;
	append_code(read_ptr[1],instcode_str);
	dec_to_hex_2(read_ptr[1],hbyte_1);
	reg_txt_2[0]=0;
	sprintf(reg_txt_2,"(iy+%s)",hbyte_1);
      }
    }
    sprintf(cmd_str,"%s %s",tmp,reg_txt_2);
    return cmd_length;
  }

  /* Logical commands with register A and number */
  if((read_ptr[0]&0xC7)==0xC6){
    cmd_length++;
    cmd_length++;
    tmp = logical_cmds[(read_ptr[0]&0x38)>>3];
    append_code(read_ptr[1],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    sprintf(cmd_str,"%s %s",tmp,hbyte_1);
    return cmd_length;
  }

  /* RET flag */
  if((read_ptr[0]&0xC7)==0xC0){
    cmd_length++;
    sprintf(cmd_str,"ret %s",flags[(read_ptr[0]&0x38)>>3]);
    return cmd_length;
  }

  /* RST ... */
  if((read_ptr[0]&0xC7)==0xC7){
    int rstval;
    cmd_length++;
    rstval=read_ptr[0]&0x38;
    dec_to_hex_2(rstval,hbyte_1);
    sprintf(cmd_str,"rst %s",hbyte_1);
    return cmd_length;
  }

  /* --- Emergency catchup routine. --- */
  fprintf(stderr,"Disasm-normal-opcode: Command not yet implemented.\n");
  return 1;
}
