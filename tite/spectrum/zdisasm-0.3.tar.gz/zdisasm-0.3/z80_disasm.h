/*
 * Z80 disassembler
 *
 * z80_disasm.h
 * (C) Mikko Nummelin 2002
 */

/*
 * Logical constants
 */
#define FALSE  0
#define TRUE   1

#define MAX_VIRTUAL_MEMORY_SIZE   (0x10000)
#define VIRTUAL_ADDR_STR_SIZE     5
#define CMD_STR_SIZE              17
#define HEXINST_STR_SIZE          9

/*
 * Converts a number between 0-15 to appropriate
 * hex number 0-F. Do NOT invoke this macro
 * with any number outside the range 0-15!
 */
#define HEXDIGIT_CHR(N) (((N)<10) ? ('0'+(N)) : ('A'-10+(N)))

/* Function headers */

int dec_to_hex_2(int,char *);
int dec_to_hex_4(int,char *);
int hex_to_dec(char *);
int append_code(int,char *);
int disasm_normal_opcode(unsigned char *,unsigned int,unsigned char *,
			 char *,unsigned char *);
void disasm_cb_opcode(unsigned char *,char *);
int  disasm_ed_opcode(unsigned char *,char *,unsigned char *);
