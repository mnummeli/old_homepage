zdisasm, (c) 2002,2005 Mikko Nummelin
===================================

This is zdisasm, a simple Z80 disassembler program which
can be used to disassemble old Sinclair ZX Spectrum and
other Z80-based computers' machine code programs.

COMPILATION/INSTALL:

$ make

USAGE:

What is required is a plain memory dump of part of
Z80-based computer's memory. In this package there is
an example file named "JETSET.MEM", which is a dump of
Sinclair ZX Spectrum 48K:s upper memory area 8000h-FFFFh
with Matthew Smith's "Jet Set Willy" game loaded into it.

An example session with zdisasm plus comments:

$ zdisasm -m 8000 -if JETSET.MEM
zdisasm: Virtual memory starts from 8000
zdisasm: Reading from JETSET.MEM
> 

The above means that zdisasm is started with JETSET.MEM
memory dump and zdisasm is made to think that it operates
on a 'virtual memory' starting from address 8000h
(good, since the original memory dump was in addresses
8000h-FFFFh in Spectrum's memory).

> m 8400
zdisasm: Pointer moved to 8400
>  

This means that machine code instructions are to be listed
from 8400h on (actual starting place in JSW).

> l 10
zdisasm: Listing 10 instructions ...
8400 di               F3
8401 ld hl,5BFF       21FF5B
8404 ld (hl),86       3686
8406 dec hl           2B
8407 ld (hl),9F       369F
8409 ld sp,5BFE       31FE5B
840C call 87CA        C3CA87
840F ld a,(bc)        0A
8410 ld b,a           47
8411 inc b            04
>  

Lists 10 machine code instructions. If one wants to trace
the program further, one notes the 'call 87CA' which means
that there's a subroutine starting from 87CAh.  Therefore

> m 87CA
zdisasm: Pointer moved to 87CA
> l 15
zdisasm: Listing 15 instructions ...
87CA xor a            AF
87CB ld (85CE),a      32CE85
87CE ld (85E1),a      32E185
87D1 ld (85CD),a      32CD85
87D4 ld (85D1),a      32D185
87D7 ld (85CB),a      32CB85
87DA ld (85E0),a      32E085
87DD ld (85DF),a      32DF85
87E0 ld a,07          3E07
87E2 ld (85CC),a      32CC85
87E5 ld a,D0          3ED0
87E7 ld (85CF),a      32CF85
87EA ld a,21          3E21
87EC ld (8420),a      322084
87EF ld hl,5DB4       21B45D
> 

And so on. When following subroutines, one should keep the
return addresses in mind or track them with paper and pencil.
When you want to exit zdisasm, just type

> q
zdisasm: Program finished successfully.


Mikko Nummelin
