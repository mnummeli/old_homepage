/*
 * Z80 disassembler
 *
 * hexcnv.c
 * (C) Mikko Nummelin 2002
 */

#include "z80_disasm.h"
#include <string.h>

/*
 * Converts decimal to 2-digit hex value. It is YOUR RESPONSIBILITY
 * to reserve space for the hex number string.
 */
int dec_to_hex_2(int decimal_number,  /* ==> Decimal number */
		 char *hex_number)    /* <== Hex number     */
{
  if(hex_number!=NULL){
    hex_number[0]=HEXDIGIT_CHR((decimal_number&(0xF0))>>4);
    hex_number[1]=HEXDIGIT_CHR(decimal_number&(0x0F));
    hex_number[2]=0; /* Strings end with a zero */
    return TRUE;
  }

  return FALSE; /* If character array isn't specified, this fails. */
}

/*
 * Converts decimal to 4-digit hex value. It is YOUR RESPONSIBILITY
 * to reserve space for the hex number string.
 */
int dec_to_hex_4(int decimal_number,  /* ==> Decimal number */
		 char *hex_number)    /* <== Hex number     */
{
  if(hex_number!=NULL){
    hex_number[0]=HEXDIGIT_CHR((decimal_number&0xF000)>>12);
    hex_number[1]=HEXDIGIT_CHR((decimal_number&0x0F00)>>8);
    hex_number[2]=HEXDIGIT_CHR((decimal_number&0x00F0)>>4);
    hex_number[3]=HEXDIGIT_CHR(decimal_number&0x000F);
    hex_number[4]=0; /* Strings end with a zero */
    return TRUE;
  }

  return FALSE; /* If character array isn't specified, this fails. */
}

/*
 * Converts hex values of arbitrary length to decimal value.
 */
int hex_to_dec(char *hex_number){
  register int i;
  register int length=strlen(hex_number);
  int retvalue=0;
  int single_char_value;

  if(hex_number!=NULL){
    for(i=0;i<length;i++){
      
      /* This expression parses a single hexadecimal
	 digit into decimal value in range 0-15. */
      if ((hex_number[i]>='0')&&(hex_number[i]<='9')){
	single_char_value=hex_number[i]-'0';
      } else if ((hex_number[i]>='A')&&(hex_number[i]<='F')){
	single_char_value=hex_number[i]-'A'+10;
      } else if((hex_number[i]>='a')&&(hex_number[i]<='f')){
	single_char_value=hex_number[i]-'a'+10;
      } else {
	single_char_value=0;
      }

      /* OR's and bit rotations are used for efficiency
	 purposes (instead of sum and multiplication).
	 This places the hexadecimal digit into
	 its correct place. */
      retvalue |= (single_char_value<<((length-i-1)<<2));
    }
  }
  return retvalue;
}

int append_code(int hexvalue, char *hexcode_str){
  char tmp_str[3];
  if(hexcode_str!=NULL){
    dec_to_hex_2(hexvalue&0xFF,tmp_str);
    strncat(hexcode_str,tmp_str,2);
    return TRUE;
  }
  return FALSE;
}
