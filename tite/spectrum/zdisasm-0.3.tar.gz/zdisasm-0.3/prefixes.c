/*
 * Z80 disassembler
 *
 * prefixes.c
 * (C) Mikko Nummelin 2002
 */

#define PREFIXED_Z80_INSTRUCTIONS   1

#include "z80_disasm.h"
#include "disasm.h"
#include <stdio.h>
#include <string.h>

/*
 * This function is called from disasm_normal_opcode and
 * resolves combinations with CBh-prefixed opcodes.
 * It currently can't handle any commands which might be
 * as well prefixed by index-register prefixes. The
 * reasons for this is, that such commands are in general
 * dangerous to use as they have some side-effects to
 * ordinary registers as well. The disasm_normal_opcode
 * should, however, print a warning to stderr in those
 * cases.
 */
void disasm_cb_opcode
(unsigned char *read_ptr,
 char          *cmd_str)
{
  char *tmp_cmd,*tmp_reg,tmp_bitno;
  fl.cb_resolved=FALSE;
  if((read_ptr[0]&0xC0)==0x00){
    tmp_cmd=rotating_cmds[(read_ptr[0]&0x38)>>3];
    tmp_reg=regs[read_ptr[0]&0x07];
    sprintf(cmd_str,"%s %s",tmp_cmd,tmp_reg);
    fl.cb_resolved=TRUE;
  } else {
    tmp_cmd   = bit_cmds[(read_ptr[0]&0xC0)>>6];
    tmp_reg   = regs[read_ptr[0]&0x07];
    tmp_bitno = '0'+((read_ptr[0]&0x38)>>3);
    sprintf(cmd_str,"%s %c,%s",tmp_cmd,tmp_bitno,tmp_reg);
    fl.cb_resolved=TRUE;
  }
  return;
}

int disasm_ed_opcode
(unsigned char *read_ptr,
 char          *cmd_str,
 unsigned char *instcode_str)
{
  char *tmp_regpair,*tmp_reg,*tmp_pre,*tmp_post;
  char hbyte_1[3];
  char hbyte_2[3];
  int cmd_length=1;
  fl.ed_resolved=FALSE;

  if(((read_ptr[0]&0xC0)==0x00)||((read_ptr[0]&0xF7)==0x77)){
    sprintf(cmd_str,"nop");
    fl.ed_resolved=TRUE;
  }

  switch(read_ptr[0]){
  case 0x46:
    sprintf(cmd_str,"im 0");
    fl.ed_resolved=TRUE;
    break;
  case 0x4E:
    sprintf(cmd_str,"im 0/1");
    fl.ed_resolved=TRUE;
    break;
  case 0x56:
    sprintf(cmd_str,"im 1");
    fl.ed_resolved=TRUE;
    break;
  case 0x5E:
    sprintf(cmd_str,"im 2");
    fl.ed_resolved=TRUE;
    break;
  case 0x47:
    sprintf(cmd_str,"ld i,a");
    fl.ed_resolved=TRUE;
    break;
  case 0x4F:
    sprintf(cmd_str,"ld r,a");
    fl.ed_resolved=TRUE;
    break;
  case 0x57:
    sprintf(cmd_str,"ld a,i");
    fl.ed_resolved=TRUE;
    break;
  case 0x5F:
    sprintf(cmd_str,"ld a,r");
    fl.ed_resolved=TRUE;
    break;
  case 0x67:
    sprintf(cmd_str,"rrd");
    fl.ed_resolved=TRUE;
    break;
  case 0x6F:
    sprintf(cmd_str,"rld");
    fl.ed_resolved=TRUE;
    break;
  }

  if((read_ptr[0]&0xC7)==0x44){
    sprintf(cmd_str,"neg");
    fl.ed_resolved=TRUE;
  }

  if((read_ptr[0]&0xCF)==0x45){
    sprintf(cmd_str,"reti");
    fl.ed_resolved=TRUE;
  }

  if((read_ptr[0]&0xCF)==0x4D){
    sprintf(cmd_str,"retn");
    fl.ed_resolved=TRUE;
  }

  if((read_ptr[0]&0xC6)==0x40){
    tmp_reg=regs[(read_ptr[0]&0x38)>>3];
    if(strcmp(tmp_reg,"(hl)")==0){
      sprintf(cmd_str,"io?");
      fl.ed_resolved=TRUE;
      fprintf(stderr,"Disasm-EDh: Erroneous I/O access.\n");
      return cmd_length;
    }
    (BITMASK(0)&read_ptr[0]) ?
      sprintf(cmd_str,"out (bc),%s",tmp_reg) :
      sprintf(cmd_str,"in %s,(bc)",tmp_reg);
    fl.ed_resolved=TRUE;
  }

  /* SBC/ADC hl, register pair */
  if((read_ptr[0]&0xC7)==0x42){
    tmp_regpair=regpairs_a[(read_ptr[0]&0x30)>>4];
    if(fl.ix_on) {
      ((read_ptr[0]&0x08)==0x08) ?
	sprintf(cmd_str,"adc ix,%s",tmp_regpair) :
	sprintf(cmd_str,"sbc ix,%s",tmp_regpair);  
    } else if(fl.iy_on) {
      ((read_ptr[0]&0x08)==0x08) ?
	sprintf(cmd_str,"adc iy,%s",tmp_regpair) :
	sprintf(cmd_str,"sbc iy,%s",tmp_regpair);  
    } else {
      ((read_ptr[0]&0x08)==0x08) ?
	sprintf(cmd_str,"adc hl,%s",tmp_regpair) :
	sprintf(cmd_str,"sbc hl,%s",tmp_regpair);  
    }
    fl.ed_resolved=TRUE;
  }

  /* LD register pair,(address) */
  if((read_ptr[0]&0xCF)==0x03){
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    if(fl.ix_on && (read_ptr[0]==0x63)){
      sprintf(cmd_str,"ld ix,(%s%s)",hbyte_2,hbyte_1);
    } else if(fl.iy_on && (read_ptr[0]==0x63)){
      sprintf(cmd_str,"ld iy,(%s%s)",hbyte_2,hbyte_1);
    } else {
      sprintf(cmd_str,"ld %s,(%s%s)",
	      regpairs_a[(read_ptr[0]&0x30)>>4],hbyte_2,hbyte_1);
    }
    fl.ed_resolved=TRUE;
  }

  /* LD (address),register pair */
  if((read_ptr[0]&0xCF)==0x0B){
    cmd_length++;
    cmd_length++;
    append_code(read_ptr[1],instcode_str);
    append_code(read_ptr[2],instcode_str);
    dec_to_hex_2(read_ptr[1],hbyte_1);
    dec_to_hex_2(read_ptr[2],hbyte_2);
    if(fl.ix_on && (read_ptr[0]==0x63)){
      sprintf(cmd_str,"ld (%s%s),ix",hbyte_2,hbyte_1);
    } else if(fl.iy_on && (read_ptr[0]==0x63)){
      sprintf(cmd_str,"ld (%s%s),iy",hbyte_2,hbyte_1);
    } else {
      sprintf(cmd_str,"ld (%s%s),%s",hbyte_2,hbyte_1,
	      regpairs_a[(read_ptr[0]&0x30)>>4]);
    }
    fl.ed_resolved=TRUE;
  }

  if((read_ptr[0]&0xE4)==0xA0){
    tmp_pre=loop_cmd_start[read_ptr[0]&0x03];
    tmp_post=loop_cmd_end[(read_ptr[0]&0x18)>>3];
    sprintf(cmd_str,"%s%s",tmp_pre,tmp_post);
    fl.ed_resolved=TRUE;
  }

  return cmd_length;
}
