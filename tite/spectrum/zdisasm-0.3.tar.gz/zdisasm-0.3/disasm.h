/*
 * Z80 disassembler
 *
 * disasm.h
 * (C) Mikko Nummelin 2002
 */

/*
 * Struct for handling IX and IY register pairs
 * plus prefix-definitions.
 */
struct flags_def {
  int ix_on;
  int iy_on;
  int cb_resolved;
  int ed_resolved;
};

typedef struct flags_def flags_stc;
flags_stc fl;

/*
 * For single bit masking purposes.
 * For example:
 * (BITMASK(4) & r)  is TRUE if bit 4 of r is set.
 * (BITMASK(2) & ~r) is TRUE if bit 2 of r is not set.
 * r |= BITMASK(3)   sets bit 3 of r.
 * r &= ~BITMASK(6)  resets bit 6 of r.
 */
#define BITMASK(N) (1<<(N))

/*
 * Register array
 */
static char regs[8][5] = {"b","c","d","e","h","l","(hl)","a"};

/*
 * Register pair arrays
 */
static char regpairs_a[4][3] = {"bc","de","hl","sp"};

#ifndef PREFIXED_Z80_INSTRUCTIONS
static char regpairs_b[4][3] = {"bc","de","hl","af"};

/*
 * Flag array
 */
static char flags[8][3] = {"nz","z","nc","c",
			   "po","pe","p","m"};

/*
 * Command arrays
 */
static char logical_cmds[8][4]   = {"add","adc","sub","sbc",
				    "and","xor","or","cp"};
static char misc_cmds[8][5]      = {"rlca","rrca","rla","rra",
				    "daa","cpl","scf","ccf"};
#endif

#ifdef PREFIXED_Z80_INSTRUCTIONS
static char rotating_cmds[8][4]  = {"rlc","rrc","rl","rr",
				    "sla","sra","sll","srl"};
static char bit_cmds[4][4]       = {"","bit","set","res"};
static char loop_cmd_start[4][3] = {"ld","cp","in","ot"};
static char loop_cmd_end[4][3]   = {"i","d","ir","dr"};
#endif
