/*
 * Z80 disassembler
 *
 * zdisasm.h
 * (C) Mikko Nummelin 2002
 */

#define MAX_FILENAME_LENGTH 64

/*
 * Virtual memory for temporarily dumping file into
 */
typedef struct {
  unsigned char mempage[0x10000];
  int start;
  int offset;
} vmem_stc;

vmem_stc vmem;
