package org.mn.z80util.z80;

public class MockZ80 implements Z80 {

	public void NMI() {
		// TODO Auto-generated method stub
		
	}

	public void executeNextCommand() {
		// TODO Auto-generated method stub
		
	}

	public byte getReg(int regno) {
		// TODO Auto-generated method stub
		return 0;
	}

	public short getRegPair(int regpairno) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getTStates() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void interrupt() {
		// TODO Auto-generated method stub
		
	}

	public void reset() {
		// TODO Auto-generated method stub
		
	}

	public void setFlag(int flag, boolean value) {
		// TODO Auto-generated method stub
		
	}

	public void setHaltState(boolean value) {
		// TODO Auto-generated method stub
		
	}

	public void setReg(int regno, byte value) {
		// TODO Auto-generated method stub
		
	}

	public void setRegPair(int regpairno, short value) {
		// TODO Auto-generated method stub
		
	}

	public void setTStates(int value) {
		// TODO Auto-generated method stub
		
	}

	public void setUla(AddressBusProvider ula) {
		// TODO Auto-generated method stub
		
	}

	public boolean testFlag(int flag) {
		// TODO Auto-generated method stub
		return false;
	}

}
