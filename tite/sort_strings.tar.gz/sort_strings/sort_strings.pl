#!/usr/bin/perl

# A vote-mergesort algorithm. Takes an input file of strings and asks the user
# of preference relation of items. Sometimes the algorithm prompts 'middle',
# i.e. neither the best nor least preferred of three items to speed up
# partitioning.
#
# Mikko Nummelin, 2008

use strict;
use warnings;

sub vote {
	print "Preferred of these:\n";
	print "0: $_[0]1: $_[1]? ";
	my $ans=<STDIN>;
	return 0 if ($ans=='0');
	return 1 if ($ans=='1');
	return -1; # ERROR
}

sub find_pivot {
	print "Not the best nor least preferred of these";
	print " (just for speeding up partitioning):\n";
	my $lastind=$#_;
	my $midind=int($lastind/2);
	print "0: $_[0]1: $_[$midind]2: $_[$lastind]? ";
	my $ans=<STDIN>;
	return 0 if ($ans==0);
	return $midind if ($ans==1);
	return $lastind if ($ans==2);
	
	return undef; # ERROR
}

sub sort_strings {
	my $nstrings=@_;
	
	# Trivial cases
	return undef if ($nstrings<=0);
	return $_[0] if ($nstrings==1);
	if ($nstrings==2) {
		if (vote($_[0],$_[1])) {
			return ($_[1],$_[0]);
		} else {
			return ($_[0],$_[1]);
		}
	}
	
	my $pivot_ind = find_pivot (@_);
	my @first;
	my @second;
	
	for (my $i=0; $i<$nstrings; $i++) {
		unless($i==$pivot_ind) {
			my $ans=vote($_[$i],$_[$pivot_ind]);
			if ($ans) {
				push (@second,$_[$i]);
			} else {
				push (@first,$_[$i]);
			}
		}
	}
	
	@first=sort_strings(@first);
	@second=sort_strings(@second);
	my @retval;
	push @retval,@first;
	push @retval,$_[$pivot_ind];
	push @retval,@second;
	
	return @retval;
}

my @strings;
open (INFILE, "<", $ARGV[0]);

for (<INFILE>) {
	push (@strings, $_ ) unless ($_ =~ /^\s/);
}

close INFILE;

@strings=sort_strings @strings;

for (@strings) {
	print ;
}
