Catch - yksinkertainen Xlib:iin perustuva peli
==============================================

(c) Mikko Nummelin, 2007, 2008


S��NN�T

Catch on GNU/Linux-j�rjestelmiss� toimiva yksinkertainen Xlib:iin perustuva
peli, jossa tarkoituksena on ker�t� pisaroita astiaan ja tyhjent�� astia
ruudun laidassa ennen kuin se vuotaa yli. Ylivuodosta tai pisaran tippumisesta
maahan seuraa palo, kolmesta palosta peli p��ttyy. Kiinniotetusta pisarasta
saa yhden pisteen, tyhjennetyst� astiasta saa pisteit� t�ytt�asteen toisessa
potenssissa, esimerkiksi vain yhden pisaran sis�lt�v�st� astiasta 1 pisteen,
mutta t�ydest� 25 pistett�!

Peli on tarkoitettu l�hinn� demoamaan Xlib-funktioiden k�ytt��.


OHJAUS

p == pys�ytys ja jatkaminen, alussa peli on pys�ytettyn�
nuolet oikealle ja vasemmalle == liikkuminen oikealle ja vasemmalle
nuoli alas == astian pys�ytys


K��NT�MINEN JA K�YNNISTYS

$ make

$ ./catch
