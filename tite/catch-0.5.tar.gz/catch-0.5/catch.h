/**
 * Catch - a simple Xlib-based game.
 * (c) 2007, Mikko Nummelin
 */

#ifndef CATCH_H
#define CATCH_H

/* Standard includes */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

/* Global variables. Macro GLOBAL should be either empty
 * (in main file ''catch.c'') or ''extern'' (elsewhere). */

/* Default display */
GLOBAL Display *display;

/* Default screen */
GLOBAL int screen;

/* Color pixels */
GLOBAL unsigned long black, white;

/* Default colormap */
GLOBAL Colormap colormap;

/* Default GC */
GLOBAL GC gc;

/* Root window */
GLOBAL Window root_window;

/* Game window */
GLOBAL Window game_window;

/* Event */
GLOBAL XEvent event;

/* Game variables */
GLOBAL Pixmap glass[6], drop, digit0, digit1;
GLOBAL double prev_time, curr_time;
GLOBAL int glass_place, drop_x, drop_y;
GLOBAL int move_left, move_right, paused, score, fill, miss;

/* Functions */

/* Signal handler and game exiting function */
void end_program(int signum);

void init_rand_from_clock();

/* Game update function */
void game_update();

/* Prints score and misses */
void print_score();

/* Event chooser function */
void handle_events();

/* Timer function */
double dtime();

#endif
