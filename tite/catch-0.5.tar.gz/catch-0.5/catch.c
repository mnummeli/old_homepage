/**
 * Catch - a simple Xlib based game.
 * (c) 2007, Mikko Nummelin
 */

/* Note: $ indent -kr -ci8 -i8 */

#define GLOBAL
#include "catch.h"
#undef GLOBAL

int main(int argc, char *argv[])
{
	int i;
	char tmpname[16];
	XSizeHints *size_hints;
	char *window_name = "Catch - (c) 2007, Mikko Nummelin.";
	char *icon_name = "Catch";
	XTextProperty window_name_property, icon_name_property;

	/* Prologue, initializing globals */
	display = XOpenDisplay(NULL);
	screen = DefaultScreen(display);
	black = BlackPixel(display, screen);
	white = WhitePixel(display, screen);
	colormap = DefaultColormap(display, screen);
	gc = DefaultGC(display, screen);
	root_window = RootWindow(display, screen);

	/* Creates window */
	game_window =
		XCreateSimpleWindow(display, root_window, 0, 0, 512, 384,
				    0, white, black);

	/* Makes window unresizable */
	size_hints = XAllocSizeHints();
	size_hints->flags = PMinSize | PMaxSize;
	size_hints->min_width = 512;
	size_hints->min_height = 384;
	size_hints->max_width = 512;
	size_hints->max_height = 384;
	XSetWMNormalHints(display, game_window, size_hints);
	XFree(size_hints);

	/* Sets window and icon titles */
	XStringListToTextProperty(&window_name, 1, &window_name_property);
	XStringListToTextProperty(&icon_name, 1, &icon_name_property);
	XSetWMName(display, game_window, &window_name_property);
	XSetWMIconName(display, game_window, &icon_name_property);

	/* Sets GC colors */
	XSetBackground(display, gc, black);
	XSetForeground(display, gc, white);

	/* Read color bitmaps to variables */
	for(i=0;i<6;i++) {
		sprintf(tmpname,"glass_%d_5.xpm",i);
		XpmReadFileToPixmap(display, game_window, tmpname,
		    &(glass[i]), NULL, NULL);
	}
	XpmReadFileToPixmap(display, game_window, "drop.xpm",
			    &drop, NULL, NULL);
	XpmReadFileToPixmap(display, game_window, "digitaali0.xpm",
			    &digit0, NULL, NULL);
	XpmReadFileToPixmap(display, game_window, "digitaali1.xpm",
			    &digit1, NULL, NULL);

	/* Shows window */
	XMapWindow(display, game_window);

	/* Handles most important signals */
	signal(SIGINT, end_program);
	signal(SIGTERM, end_program);

	/* Selects events to be handled */
	XSelectInput(display, game_window,
		     KeyPressMask | StructureNotifyMask | ExposureMask);

	init_rand_from_clock();

	/* Initializes variables */
	prev_time = 0.0;
	glass_place = 240;
	drop_x = 240;
	drop_y = 0;
	move_left = 0;
	move_right = 0;
	paused = 1;
	score = 0;
	fill = 0;
	miss = 0;

	/* Event loop */
	while (1) {
		if (!paused)
			game_update();

		/* There must be a positive number of events in
		 * the queue in order to proceed further */
		if (XEventsQueued(display, QueuedAfterFlush) > 0) {
			XNextEvent(display, &event);
			handle_events(event);
		}
	}
}

/* Game update routine */
void game_update()
{
	curr_time = dtime();

	/* This check is important. It determines, how long
	 * does it take until ''next round'' when game is supposed
	 * to be updated. Decreasing the sojourn time makes the
	 * game more difficult. */
	if (curr_time - prev_time > 0.002 + 1.0 / (score + 50)) {
		prev_time = curr_time;

		/* Clears the previous ''glass'' sprite */
		XClearArea(display, game_window,
			   glass_place, 320, 32, 32, False);

		/* Bonus for emptying the glass */
		if ((glass_place <= 16) || (glass_place >= 463)) {
			score += fill * fill;
			fill = 0;
			print_score();
		}

		/* Moves ''glass'' sprite as appropriate */
		if ((move_left) && (glass_place >= 16)) {
			glass_place -= 4;
		} else if ((move_right)
			   && (glass_place <= 463)) {
			glass_place += 4;
		}

		/* Sets the new ''glass'' sprite */
		XCopyArea(display, glass[fill], game_window,
			  gc, 0, 0, 32, 32, glass_place, 320);

		/* Clears the previous ''drop'' sprite */
		XClearArea(display, game_window, drop_x,
			   drop_y, 16, 16, False);

		/* New drop */
		if (drop_y == 0) {
			drop_x = 64 + rand() / (RAND_MAX / 352);
		}

		/* Moves drop down */
		drop_y += 3;

		/* You didn't catch it and were killed! */
		if (drop_y > 336) {
			miss++;
			print_score();
			if (miss >= 3) {
				printf("==> %d\n", score);
				end_program(0);
			}
			drop_y = 0;
		}

		if ((drop_y >= 304) && (drop_y <= 336)) {
			if ((drop_x >= glass_place - 16) &&
			    (drop_x <= glass_place + 32)) {
				/* You scored */
				score++;
				if (fill < 5)
					fill++;
				else {
					miss++;
					fill = 0;
					if (miss >= 3) {
						printf("==> %d\n", score);
						end_program(0);
					}
				}
				print_score();
				drop_y = 0;
			}
		}

		/* Sets the new ''drop'' sprite */
		XCopyArea(display, drop, game_window, gc,
			  0, 0, 16, 16, drop_x, drop_y);
	}
}

/* Prints score and misses to lower screen */
void print_score()
{
	int i;
	for (i = 0; i < miss; i++) {
		XCopyArea(display, drop, game_window, gc,
			  0, 0, 16, 16, 32 + i * 20, 364);
	}
	for (i = 0; i < 8; i++) {
		if (score & (1 << (7 - i))) {
			XCopyArea(display, digit1, game_window, gc,
				  0, 0, 16, 16, 256 + i * 16, 364);
		} else {
			XCopyArea(display, digit0, game_window, gc,
				  0, 0, 16, 16, 256 + i * 16, 364);
		}
	}
}

/* Internals of the event loop, i.e. event chooser */
void handle_events()
{
	unsigned int keycode;
	KeySym keysym;
	switch (event.type) {
	case KeyPress:
		keycode = event.xkey.keycode;
		keysym = XKeycodeToKeysym(display, keycode, 0);
		switch (keysym) {
		case XK_P:
		case XK_p:
			paused = !paused;
			break;
		case XK_Q:
		case XK_q:
			end_program(0);
		case XK_Left:
			move_left = 1;
			move_right = 0;
			break;
		case XK_Right:
			move_left = 0;
			move_right = 1;
			break;
		case XK_Down:
			move_left = 0;
			move_right = 0;
			break;
		}
		break;
	case Expose:
		print_score();
		/* Redraws the ''glass'' sprite */
		XCopyArea(display, glass[fill], game_window,
			  gc, 0, 0, 32, 32, glass_place, 320);
		/* Redraws the ''drop'' sprite */
		XCopyArea(display, drop, game_window, gc,
			  0, 0, 16, 16, drop_x, drop_y);
		break;
	case DestroyNotify:
		end_program(0);
	}
}

/* Timer function, returns system clock time in seconds with millisecond
 * precision */
double dtime()
{
	struct timeval tv;
	double rval;

	gettimeofday(&tv, NULL);

	/* Whole seconds */
	rval = (double) tv.tv_sec;

	/* Millionths of seconds */
	rval += .000001 * (double) tv.tv_usec;

	return rval;
}

/* This function initializes random number generator from the system clock. */
void init_rand_from_clock()
{
	struct timeval tv;

	gettimeofday(&tv, NULL);
	srand(tv.tv_usec);
}

/* Signal handler and game exiting function */
void end_program(int signum)
{
	printf("Exiting ...\n");
	XDestroyWindow(display, game_window);
	XCloseDisplay(display);
	exit(EXIT_SUCCESS);
}
