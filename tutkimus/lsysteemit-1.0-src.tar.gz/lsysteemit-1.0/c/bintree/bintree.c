#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double pii;
int iteraatiot;

void P(double x,double y,double l,double phi,int n) {
    if(n>=0) {
        printf("(%1.5lf,%1.5lf)->(%1.5lf,%1.5lf)",
               x,y,x+l*cos(phi),y+l*sin(phi));
        if(n==0)
            printf("*\n");
        else
            printf("-\n");
        P(x+l*cos(phi),y+l*sin(phi),l/3,phi+pii/5,n-1);
        P(x+l*cos(phi),y+l*sin(phi),l/4,phi-pii/3,n-1);
    }
}

int main(int argc, char *argv[]) {
    pii=2*acos(0);
    if(argc>1)
        iteraatiot=atoi(argv[1]);
    else
        iteraatiot=3;
    P(0,0,1,pii/2,iteraatiot);
    return 0;
}
