#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "vec.h"

/* T�h�n 512x512-taulukkoon piirret��n kuvioita */
unsigned char *kuva;

FILE *pnm_tiedosto;

double pii;
int iteraatiot;
vec_3d s0,t0,n0;

void piste(double x,double y,double arvo) {
	if((x>=0)&&(x<=511)&&(y>=0)&&(y<=511)) {
		kuva[(int)x+512*(int)y]=arvo;
	}
}

unsigned char pisteen_arvo(double x,double y) {
	return kuva[(int)x+512*(int)y];
}

void maalaa_tausta(double arvo) {
	register int i,j;
	for(i=0;i<512;i++) {
		for(j=0;j<512;j++) {
			piste((double)j,(double)i,arvo);
		}
	}
}

void viiva_iteroi(double x0,double y0,double x1,double y1,double arvo) {
	if(((x0-x1)<=-1.0)||((x0-x1)>=1.0)||
		((y0-y1)<=-1.0)||((y0-y1)>=1.0)) {
		/* Piste puoleenv�liin */
		piste(x0/2+x1/2,y0/2+y1/2,arvo);
		/* Uudet iteroinnit */
		viiva_iteroi(x0,y0,x0/2+x1/2,y0/2+y1/2,arvo);
		viiva_iteroi(x0/2+x1/2,y0/2+y1/2,x1,y1,arvo);
	}
}

void viiva(double x0,double y0,double x1,double y1, double arvo) {
	piste(x0,y0,arvo);
	piste(x1,y1,arvo);
	viiva_iteroi(x0,y0,x1,y1,arvo);
}

void viiva_3d(const vec_3d *r, const vec_3d *dr, double arvo) {
	viiva(256.0+64.0*r->x+16.0*r->y,448.0-64.0*r->z-16.0*r->y,
		256.0+64.0*(r->x+dr->x)+16.0*(r->y+dr->y),
		448.0-64.0*(r->z+dr->z)-16.0*(r->y+dr->y),
		arvo);
}

void kuva_pnm() {
	register int i,j;
	int arvo;
	pnm_tiedosto=fopen("3dtree.pnm","wb");
	fprintf(pnm_tiedosto,"P3\n512 512\n255\n");
	for(i=0;i<512;i++) {
		for(j=0;j<512;j++) {
			arvo=pisteen_arvo((double)j,(double)i);
			fprintf(pnm_tiedosto,"%d %d %d\n",
				arvo,arvo,arvo);
		}
	}
	fclose(pnm_tiedosto);
}

void Oksa(const vec_3d *s, const vec_3d *t, const vec_3d *n,
	const double l, int m) {
	vec_3d lt,b,a1,a2,a3,a4,o1,o2;

	mult_3d(l,t,&lt);
	viiva_3d(s,&lt,0);
	if(m>0) {
		cross_3d(t,n,&b);
		mult_3d(cos(1.0*pii/12.0),t,&a1);
		mult_3d(sin(1.0*pii/12.0),&b,&a2);
		mult_3d(cos(1.0*pii/12.0),n,&a3);
		mult_3d(-cos(1.0*pii/12.0),n,&a4);

		Oksa(plus_3d(s,&lt,&o1),plus_3d(&a1,&a2,&o2),n,0.5*l,m-1);
		Oksa(plus_3d(s,&lt,&o1),plus_3d(&a3,&a2,&o2),
			neg_3d(t,&o2),0.5*l,m-1);
		Oksa(plus_3d(s,&lt,&o1),plus_3d(&a4,&a2,&o2),t,0.5*l,m-1);
	}
}

void Runko(const vec_3d *s, const vec_3d *t, const vec_3d *n,
	const double l, int m) {
	vec_3d lt,b,a1,a2,a3,a4,a5,o1,o2,o3;

	mult_3d(l,t,&lt);
	viiva_3d(s,&lt,0);
	if(m>0) {
		/* Apulaskutoimituksia */
		cross_3d(t,n,&b);
		mult_3d(cos(5.0*pii/12.0),t,&a1);
		mult_3d(sin(5.0*pii/12.0),n,&a2);
		mult_3d(sin(5.0*pii/12.0),&b,&a3);
		mult_3d(-sin(5.0*pii/12.0),n,&a4);
		mult_3d(-sin(5.0*pii/12.0),&b,&a5);
		
		/* Rekursiiviset kutsut */
		Runko(plus_3d(s,&lt,&o1),t,n,0.8*l,m-1);
		Oksa(plus_3d(s,&lt,&o1),plus_3d(&a1,&a5,&o2),n,0.6*l,m-1);
		Oksa(plus_3d(s,&lt,&o1),plus_3d(&a1,&a2,&o2),&b,0.6*l,m-1);
		Oksa(plus_3d(s,&lt,&o1),plus_3d(&a1,&a3,&o2),
			neg_3d(n,&o3),0.6*l,m-1);
		Oksa(plus_3d(s,&lt,&o1),plus_3d(&a1,&a4,&o2),
			neg_3d(&b,&o3),0.6*l,m-1);
	}
}

int main(int argc, char *argv[]) {
	pii=2*acos(0);
	if(argc>1)
		iteraatiot=atoi(argv[1]);
	else
		iteraatiot=3;
	kuva=malloc(512*512);
	maalaa_tausta(255);
	
	/* Rungon alkuarvot */
	s0.x=0.0;s0.y=0.0;s0.z=0.0;
	t0.x=0.0;t0.y=0.0;t0.z=1.0;
	n0.x=-1.0;n0.y=0.0;n0.z=0.0;

	/* L-systeemin kutsu */
	Runko(&s0,&t0,&n0,1.0,iteraatiot);

	kuva_pnm();
	free(kuva);
	return 0;
}
