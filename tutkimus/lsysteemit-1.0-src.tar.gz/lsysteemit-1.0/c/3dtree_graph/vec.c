#include "vec.h"

vec_3d *neg_3d(const vec_3d *in, vec_3d *out) {
	out->x = -in->x;
	out->y = -in->y;
	out->z = -in->z;
	return out;
}

vec_3d *mult_3d(const double scalar, const vec_3d *in, vec_3d *out) {
	out->x = scalar*in->x;
	out->y = scalar*in->y;
	out->z = scalar*in->z;
	return out;
}

vec_3d *plus_3d(const vec_3d *in1, const vec_3d *in2, vec_3d *out) {
	out->x = in1->x + in2->x;
	out->y = in1->y + in2->y;
	out->z = in1->z + in2->z;
	return out;
}

double dot_3d(const vec_3d *in1, const vec_3d *in2) {
	return in1->x*in2->x+in1->y*in2->y+in1->z*in2->z;
}

vec_3d *cross_3d(const vec_3d *in1, const vec_3d *in2, vec_3d *out) {
	out->x=in1->y*in2->z-in2->y*in1->z;
	out->y=in1->z*in2->x-in2->z*in1->x;
	out->z=in1->x*in2->y-in2->x*in1->y;
	return out;
}
