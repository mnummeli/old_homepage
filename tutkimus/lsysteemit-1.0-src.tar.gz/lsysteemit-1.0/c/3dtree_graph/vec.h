typedef struct {
	double x,y,z;
} vec_3d;

vec_3d *neg_3d(const vec_3d *in, vec_3d *out);
vec_3d *mult_3d(const double scalar, const vec_3d *in, vec_3d *out);
vec_3d *plus_3d(const vec_3d *in1, const vec_3d *in2, vec_3d *out);
double dot_3d(const vec_3d *in1, const vec_3d *in2);
vec_3d *cross_3d(const vec_3d *in1, const vec_3d *in2, vec_3d *out);
