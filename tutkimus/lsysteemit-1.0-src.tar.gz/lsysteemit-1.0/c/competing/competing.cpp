#include <iostream>
#include <fstream>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "competing.hpp"

using namespace std;

Vertice::Vertice(double x, double y, double l, double d) {
	start_x=x;
	start_y=y;
	length=l;
	direction=d;
}

double Vertice::getStartX() {
	return start_x;
}

double Vertice::getStartY() {
	return start_y;
}

double Vertice::getEndX() {
	return start_x+length*cos(direction);
}

double Vertice::getEndY() {
	return start_y+length*sin(direction);
}

double Vertice::getLength() {
	return length;
}

double Vertice::getDirection() {
	return direction;
}

Vertice *Vertice::translate(double newLength, double arc) {
	Vertice *newVert;
	double newDirection;
	newDirection=direction+arc;
	if(newDirection>2*acos(0.0))
		newDirection-=4*acos(0.0);
	if(newDirection<-2*acos(0.0))
		newDirection+=4*acos(0.0);
	newVert=new Vertice(getEndX(),getEndY(),newLength,newDirection);
	return newVert;
}

Producible::Producible(Vertice *newVert, int newRound) {
	vert=newVert;
	round=newRound;
}

Vertice *Producible::getVertice() {
	return vert;
}

int Producible::getRound() {
	return round;
}

LList::LList() {
	strncpy(type,"dummy",16);
	contentP=NULL;
	nextP=NULL;
}

LList::LList(char *newType, void *newContentP) {
	strncpy(type,newType,16);
	contentP=newContentP;
	nextP=NULL;
}

void LList::addElement(char *newType, void *newContentP) {
	LList *newNodeP;
	newNodeP=new LList(newType, newContentP);
	newNodeP->setNext(nextP);
	nextP=newNodeP;
}

char *LList::getType() {
	return type;
}

void *LList::getElement() {
	return contentP;
}

void LList::setNext(LList *newNextP) {
	nextP=newNextP;
}

LList *LList::getNext() {
	return nextP;
}

int LList::isLast() {
	if(nextP==NULL)
		return TRUE;
	return FALSE;
}

int LList::deleteNext() {
	LList *tmp;
	if(!isLast()) {
		tmp=getNext()->getNext();
		delete getNext();
		setNext(tmp);
		// There was an item to delete
		return TRUE;
	}
	// There is no next node
	return FALSE;
}

void LList::purge() {
	while(!isLast())
		deleteNext();
}

Point::Point(double newX, double newY) {
	x=newX;
	y=newY;
}

PointEnv::PointEnv(LList *newPointListP) {
	pointListP=newPointListP;
}

int PointEnv::countNear(double x, double y, double dist) {
	int counter;
	LList *listP;
	Point *pointP;
	counter=0;
	listP=pointListP;
	while(listP) {
		if(!memcmp(listP->getType(),"point",5)) {
			pointP=(Point *)listP->getElement();
			if(sqrt((pointP->x-x)*(pointP->x-x)+
				(pointP->y-y)*(pointP->y-y))<dist)
				counter++;
		}
		listP=listP->getNext();
	}
	return counter;
}

PNMCanvas::PNMCanvas(int x, int y, int ux, int uy) {
	setOrg(x,y);
	setUnits(ux,uy);
}

void PNMCanvas::setAttr(int x, int y, int *red, int *green, int *blue) {
	if((x>=0)&&(x<512)&&(y>=0)&&(y<512)) {
		if(red)
			cnv[y][x][REDC]   = *red;
		if(green)
			cnv[y][x][GREENC] = *green;
		if(blue)
			cnv[y][x][BLUEC]  = *blue;
	}
}

int PNMCanvas::getAttr(int x, int y, int *red, int *green, int *blue) {
	if((x>=0)&&(x<512)&&(y>=0)&&(y<512)) {
		if(red)
			*red   = cnv[y][x][REDC];
		if(green)
			*green = cnv[y][x][GREENC];
		if(blue)
			*blue  = cnv[y][x][BLUEC];
		return TRUE;
	}
	return FALSE;
}

void PNMCanvas::setOrg(int x, int y) {
	orgX=x;
	orgY=y;
}

void PNMCanvas::getOrg(int *x, int *y) {
	if(x)
		*x=orgX;
	if(y)
		*y=orgY;
}

void PNMCanvas::setUnits(int x, int y) {
	unitX=x;
	unitY=y;
}

void PNMCanvas::getUnits(int *x, int *y) {
	if(x)
		*x=unitX;
	if(y)
		*y=unitY;
}

void PNMCanvas::plot(double x, double y, double red, double green, double blue) {
	int r,g,b;
	r=(int)(255.0*red);
	g=(int)(255.0*green);
	b=(int)(255.0*blue);
	setAttr(orgX+(int)(512.0*x)*unitX/512,
		orgY+(int)(512.0*y)*unitY/512,
		&r,&g,&b);
}

void PNMCanvas::draw(double startX, double startY, double endX, double endY,
		double red, double green, double blue) {
	double pixX,pixY;
	pixX=1.0/(double)unitX;
	pixY=1.0/(double)unitY;
	// Draws start and endpoints
	plot(startX,startY,red,green,blue);
	plot(endX,endY,red,green,blue);
	// Splits the original line into two lines and draws them.
	// Recursion ends when lines are short enough to account for
	// less than a pixel.
	if(4*(endX-startX)*(endX-startX)+4*(endY-startY)*(endY-startY) >
		pixX*pixX+pixY*pixY) {
		draw(startX,startY,startX/2+endX/2,startY/2+endY/2,red,green,blue);
		draw(startX/2+endX/2,startY/2+endY/2,endX,endY,red,green,blue);
	}
}

void PNMCanvas::clean(double red, double green, double blue) {
	int i,j,r,g,b;
	r=(int)(255.0*red);
	g=(int)(255.0*green);
	b=(int)(255.0*blue);	
	for(i=0;i<512;i++) {
		for(j=0;j<512;j++) {
			setAttr(i,j,&r,&g,&b);
		}
	}
}

void PNMCanvas::exportCnv(const char *filename) {
	int i,j;
	FILE *fop;
	// Using C's library as C++:s file operations are slow
	fop=fopen(filename,"wb");
	fprintf(fop,"P3\n512 512\n255\n");
	for(i=0;i<512;i++) {
		for(j=0;j<512;j++) {
			fprintf(fop,"%d %d %d\n",
				cnv[i][j][REDC],cnv[i][j][GREENC],cnv[i][j][BLUEC]);
		}
	}
	fclose(fop);
}

int main(int argc, char *argv[]) {
	PNMCanvas cnv(128,256,20,-20);
	LList plist;
	PointEnv penv(&plist);
	Vertice v1(0.0,0.0,2.0,acos(0.0)/3.0);
	Vertice v2(15.0,0.0,2.0,-5.5*acos(0.0)/3.0);
	Vertice v3(0.0,0.0,2.0,-acos(0.0)/3.0);
	plist.addElement("point",new Point(0.0,0.0));
	plist.addElement("point",new Point(15.0,0.0));
	Vertice *vold,*vnew;
	Producible p1(&v1,10);
	Producible p2(&v2,10);
	Producible p3(&v3,10);
	Producible *pold,*pnew;
	LList *oldListP,*newListP,*tmpListP;
	oldListP=new LList;
	newListP=new LList;
	oldListP->addElement("prod",&p1);
	oldListP->addElement("prod",&p2);
	oldListP->addElement("prod",&p3);
	cnv.clean(1.0,1.0,1.0);
	// Main loop
	while(!oldListP->isLast()) {
		tmpListP=oldListP;
		while(tmpListP) {
			if(!memcmp(tmpListP->getType(),"prod",4))
				pold=(Producible *)(tmpListP->getElement());
			else
				pold=NULL;
			if(pold && (pold->getRound()>0)) {
				vold=pold->getVertice();
				if(penv.countNear(vold->getEndX(),vold->getEndY(),0.9)<2) {
					vnew=vold->translate(0.8*vold->getLength(),0.6*acos(0.0));
					plist.addElement("point",new Point(vnew->getEndX(),vnew->getEndY()));
					pnew=new Producible(vnew,pold->getRound()-1);
					newListP->addElement("prod",pnew);
					vnew=vold->translate(0.9*vold->getLength(),0.15*acos(0.0));
					plist.addElement("point",new Point(vnew->getEndX(),vnew->getEndY()));
					pnew=new Producible(vnew,pold->getRound()-1);
					newListP->addElement("prod",pnew);
					vnew=vold->translate(0.85*vold->getLength(),-0.45*acos(0.0));
					plist.addElement("point",new Point(vnew->getEndX(),vnew->getEndY()));
					pnew=new Producible(vnew,pold->getRound()-1);
					newListP->addElement("prod",pnew);
				}
			}
			if(pold) {
				vold=pold->getVertice();
				cnv.draw(vold->getStartX(),
					vold->getStartY(),
					vold->getEndX(),
					vold->getEndY(),
					0.0,0.0,0.0);
			}
			tmpListP=tmpListP->getNext();
		}
		oldListP->purge();
		delete oldListP;
		oldListP=newListP;
		newListP=new LList;
	}
	newListP->purge();
	delete newListP;
	cnv.exportCnv("test1.pnm");
	return 0;
}

// Currently only test code
#if 0
int main(int argc, char *argv[]) {
	Point *p1,*p2;
	PointEnv *penv;
	LList *plist;
	PNMCanvas *cnv;
	p1=new Point(0.0,0.0);
	p2=new Point(2.0,1.0);
	plist=new LList();
	penv=new PointEnv(plist);
	plist->addElement("point",p1);
	plist->addElement("point",p2);
	cout << penv->countNear(10.0,0.0,2.0) << endl;
	cout << penv->countNear(2.0,0.5,1.0) << endl;
	cout << penv->countNear(-0.4,-0.3,0.6) << endl;
	cout << penv->countNear(1.0,-0.1,3.0) << endl;
	cnv=new PNMCanvas(256,256,20,-20);
	cnv->clean(1.0,1.0,1.0);
	cnv->draw(0.0,0.0,1.0,0.0,1.0,0.0,0.0);
	cnv->draw(1.0,0.0,2.0,1.0,0.0,1.0,0.0);
	cnv->draw(2.0,1.0,-1.0,1.0,0.0,0.0,1.0);
	cnv->exportCnv("test1.pnm");
	return 0;
}
#endif
