#define	FALSE	0
#define	TRUE	1
#define	REDC	0
#define	GREENC	1
#define	BLUEC	2

class Vertice {
	private:
	// Start point, length and direction of this vertice.
	double start_x, start_y, length, direction;

	public:
	Vertice(double x, double y, double l, double d);
	double getStartX();
	double getStartY();
	double getEndX();
	double getEndY();
	double getLength();
	double getDirection();
	// Translates vertice to begin from this vertice's
	// end point and rotates by specified arc.
	Vertice *translate(double newLength, double arc);
};

class Producible {
	private:
	Vertice *vert;
	int round;

	public:
	Producible(Vertice *newVert, int newRound);
	Vertice *getVertice();
	int getRound();
};

class LList {
	private:
	char type[16];
	void *contentP;
	LList *nextP;

	public:
	LList();
	LList(char *newType, void *newContentP);
	void addElement(char *newType, void *newContentP);
	char *getType();
	void *getElement();
	void setNext(LList *newNextP);
	LList *getNext();
	int isLast();
	int deleteNext();
	void purge();
};

class Point {
	public:
	double x,y;
	Point(double newX, double newY);
};

class PointEnv {
	public:
	LList *pointListP;
	PointEnv(LList *newPointListP);
	// Counts number of points closer than dist to given point
	int countNear(double x, double y, double dist);
};

class PNMCanvas {
	private:
	unsigned char cnv[512][512][3];
	// gives a coordinate system for this PNMCanvas
	int orgX,orgY,unitX,unitY;

	public:
	PNMCanvas(int x, int y, int ux, int uy);
	void setAttr(int x, int y, int *red, int *green, int *blue);
	int getAttr(int x, int y, int *red, int *green, int *blue);
	void setOrg(int x, int y);
	void getOrg(int *x, int *y);
	void setUnits(int x, int y);
	void getUnits(int *x, int *y);
	void plot(double x, double y, double red, double green, double blue);
	void draw(double startX, double startY, double endX, double endY,
		double red, double green, double blue);
	void clean(double red, double green, double blue);
	// Exports the canvas in PNM format
	void exportCnv(const char *filename);
};
