#include <stdio.h>
#include "list.h"

List *create_list() {
	List *new_list;
	new_list=(List *)malloc(sizeof(List));
	new_list->this=NULL;
	new_list->next=NULL;
	return new_list;
}

void add_node(List *prev, void *new_content) {
	List *new_node;
	new_node=(List *)malloc(sizeof(List));
	new_node->this=new_content;
	new_node->next=prev->next;
	prev->next=new_node;
}

int delete_next(List *prev) {
	List *tmp;
	if(prev->next!=NULL) {
		tmp=prev->next->next;
		free(prev->next);
		prev->next=tmp;
		return TRUE;
	}
	return FALSE;
}

void clean_list(List *first_node) {
	while(first_node->next!=NULL) {
		delete_next(first_node);
	}
}

void dispose_list(List *first_node) {
	clean_list(first_node);
	free(first_node);
}

#if 0
int main(int argc, char *argv[]) {
	List *l,*n;
	int *content;
	int array[3]={3,6,8};
	
	/* Creates new list */
	l=create_list();
	
	/* Adds three nodes into it */
	add_node(l,&(array[0]));
	add_node(l,&(array[1]));
	add_node(l,&(array[2]));
	
	/* Prints list contents by iterating one by one */
	n=l->next;
	while(n!=NULL) {
		content=(int *)n->this;
		printf("%d ",*content);
		n=n->next;
	}
	printf("\r\n");
	
	/* Deletes middle node */
	delete_next(l->next);
	n=l->next;
	while(n!=NULL) {
		content=(int *)n->this;
		printf("%d ",*content);
		n=n->next;
	}
	printf("\r\n");
	
	/* Makes the cleanup */
	dispose_list(l);

	return 0; /* OK */
}
#endif
