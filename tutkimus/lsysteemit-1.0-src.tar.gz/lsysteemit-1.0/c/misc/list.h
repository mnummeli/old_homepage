#define FALSE	0
#define TRUE	1

struct list_node {
	void *this;
	struct list_node *next;
};

typedef struct list_node List;

List *create_list();
void add_node(List *, void *);
int delete_next(List *);
void clean_list(List *);
void dispose_list(List *);
