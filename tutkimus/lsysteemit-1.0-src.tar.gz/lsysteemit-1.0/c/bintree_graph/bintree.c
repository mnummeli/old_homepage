#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* T�h�n 512x512-taulukkoon piirret��n kuvioita */
unsigned char *kuva;

FILE *pnm_tiedosto;

double pii;
int iteraatiot;

void piste(double x,double y,double arvo) {
	kuva[(int)x+512*(int)y]=arvo;
}

unsigned char pisteen_arvo(double x,double y) {
	return kuva[(int)x+512*(int)y];
}

void maalaa_tausta(double arvo) {
	register int i,j;
	for(i=0;i<512;i++) {
		for(j=0;j<512;j++) {
			piste((double)j,(double)i,arvo);
		}
	}
}

void viiva_iteroi(double x0,double y0,double x1,double y1,double arvo) {
	if(((x0-x1)<=-1.0)||((x0-x1)>=1.0)||
		((y0-y1)<=-1.0)||((y0-y1)>=1.0)) {
		/* Piste puoleenv�liin */
		piste(x0/2+x1/2,y0/2+y1/2,arvo);
		/* Uudet iteroinnit */
		viiva_iteroi(x0,y0,x0/2+x1/2,y0/2+y1/2,arvo);
		viiva_iteroi(x0/2+x1/2,y0/2+y1/2,x1,y1,arvo);
	}
}

void viiva(double x0,double y0,double x1,double y1,double arvo) {
	piste(x0,y0,arvo);
	piste(x1,y1,arvo);
	viiva_iteroi(x0,y0,x1,y1,arvo);
}

void kuva_pnm() {
	register int i,j;
	int arvo;
	pnm_tiedosto=fopen("bintree.pnm","wb");
	fprintf(pnm_tiedosto,"P3\n512 512\n255\n");
	for(i=0;i<512;i++) {
		for(j=0;j<512;j++) {
			arvo=pisteen_arvo((double)j,(double)i);
			fprintf(pnm_tiedosto,"%d %d %d\n",
				arvo,arvo,arvo);
		}
	}
	fclose(pnm_tiedosto);
}

void P(double x,double y,double l,double phi,int n) {
	if(n>=0) {
		viiva(x,y,x+l*cos(phi),y+l*sin(phi),0);
		P(x+l*cos(phi),y+l*sin(phi),l/3,phi+pii/5,n-1);
		P(x+l*cos(phi),y+l*sin(phi),l/4,phi-pii/3,n-1);
	}
}

int main(int argc, char *argv[]) {
	pii=2*acos(0);
	if(argc>1)
		iteraatiot=atoi(argv[1]);
	else
		iteraatiot=3;
	kuva=malloc(512*512);
	maalaa_tausta(255);
	P(256,500,300,-pii/2,iteraatiot);
	kuva_pnm();
	free(kuva);
	return 0;
}
