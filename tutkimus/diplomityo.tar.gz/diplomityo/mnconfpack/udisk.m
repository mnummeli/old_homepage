function w=udisk(n)
% Mikko Nummelin, 2007

    t=0:2*pi/n:2*pi*(n-1)/n;
    w=exp(i*t);
end
