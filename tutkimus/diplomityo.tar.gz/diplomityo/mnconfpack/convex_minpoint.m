function [k,val]=convex_minpoint(z)
% Mikko Nummelin, 2007

    range=convhull(real(z),imag(z));
    range=sort(range(2:length(range)));
    k=1;val=Inf;
    for k1=1:length(range)
        if(abs(z(range(k1)))<val)
            k=range(k1);
            val=abs(z(k));
        end
    end
end
