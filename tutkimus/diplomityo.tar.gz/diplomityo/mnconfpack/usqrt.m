function w=usqrt(z)
% Mikko Nummelin, 2007

    w=zeros(1,length(z));
    for k1=1:length(z)
        s=sqrt(z(k1));
        if imag(s)<0 || (imag(s)==0 && real(s)<0)
            w(k1)=-s;
        else
            w(k1)=s;
        end
    end
end
