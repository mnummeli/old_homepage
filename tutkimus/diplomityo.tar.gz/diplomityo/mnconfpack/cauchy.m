function w=cauchy(z,zdata,wdata,n)
% Mikko Nummelin, 2007

    if length(zdata)~=length(wdata)
        error('zdata and wdata should have equal length.');
    end
    if nargin<4
        n=0;
    end
    w=zeros(1,length(z));
    for k1=1:length(z)
        wdata2=wdata./(zdata-z(k1)).^(n+1);
        w(k1)=0.0;
        for k2=1:length(zdata)
            if k2>1
                dzdata=zdata(k2)-zdata(k2-1);
                wval=(wdata2(k2)+wdata2(k2-1))/2;
            else
                dzdata=zdata(1)-zdata(length(zdata));
                wval=(wdata2(1)+wdata2(length(wdata)))/2;
            end
            w(k1)=w(k1)+wval*dzdata;
        end
        w(k1)=w(k1)/(2*i*pi);
    end
end
