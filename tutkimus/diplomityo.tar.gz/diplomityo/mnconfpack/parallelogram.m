function [M,polyz,polyw]=parallelogram(a,b,dens,n)
% Testiohjelma. Laatii kanonisen nelikulmion puolisuunnikkaalle,
% jonka kulmat ja samalla alkukulmat ovat 0,1,a ja b ja
% laskee t�lle konformisen modulin Joukowskin muunnoksen
% algoritmilla. On olennaista, ett� a ja b on valittava ylemm�st�
% puolitasosta ja lis�ksi niin, ett� saadaan konveksi puolisuunnikas.
%
% Mikko Nummelin, 2007

    if nargin<4
        n=1000;
    end
    if nargin<3
        dens=1000;
    end

    polyz=polygon([0,1,a,b],dens);
    polyw=polyz-(1+a+b)/4;
    polyw=josc(polyw,n);
    M=qm(polyw,1,dens+1,2*dens+1,3*dens+1);
end
