function [k,n]=innerangle2(z)
% Mikko Nummelin, 2007

    k=0;max_ang=0;
    range=convhull(real(z),imag(z));
    range=sort(range(2:length(range)));
    range=[range;range(1)];

    for k1=2:length(range)
        prev=z(range(k1))-z(range(k1-1));
        if k1<length(range)
            next=z(range(k1+1))-z(range(k1));
        else
            next=z(range(2))-z(range(k1));
        end
        ang=imag(log(next/prev));
        if ang>max_ang
            k=range(k1);
            max_ang=ang;
        end
    end
    n=pi/(pi-max_ang);
end
