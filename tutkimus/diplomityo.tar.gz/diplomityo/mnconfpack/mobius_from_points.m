function w=mobius_from_points(z,z0,z1,zinf)
    w=zeros(1,length(z));
    p0=-z0*(z1-zinf);
    p1=z1-zinf;
    q0=-zinf*(z1-z0);
    q1=z1-z0;
    for k=1:length(z)
        if z(k)==Inf
            w(k)=p1/q1;
        elseif z(k)==zinf
            w(k)=Inf;
        else
            w(k)=(p0+p1*z(k))/(q0+q1*z(k));
        end
    end
end
