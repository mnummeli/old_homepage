function w=holsqrt(z,k)
% Mikko Nummelin, 2007

    if nargin<2
        k=1;
    end
    w=zeros(1,length(z));
    p=-i;
    if k<length(z)
        for k1=k+1:length(z)
            s=sqrt(z(k1));
            if abs(s-p)>abs(s+p)
                w(k1)=-s;p=-s;
            else
                w(k1)=s;p=s;
            end
        end
    end
    if k>1
        for k1=1:k-1
            s=sqrt(z(k1));
            if abs(s-p)>abs(s+p)
                w(k1)=-s;p=-s;
            else
                w(k1)=s;p=s;
            end
        end
    end
end
