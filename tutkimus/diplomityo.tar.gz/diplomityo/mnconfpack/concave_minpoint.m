function [k,val]=concave_minpoint(z)
% Mikko Nummelin, 2007

    banned_range=convhull(real(z),imag(z));
    k=0;val=Inf;
    for k1=1:length(z)
        if abs(z(k1))<val && max(k1==banned_range)==0
            k=k1;
            val=abs(z(k));
        end
    end
end
