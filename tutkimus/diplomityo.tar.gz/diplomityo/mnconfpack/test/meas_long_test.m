1;

long=eqpolygon([1-i,1+i,5+i,5+2i,-1+2i,-1-2i,5-2i,5-i],50);
long_img=koebe(long,300);
v=cauchy(0,long,long_img);
long_img=(long_img-v)./(1-v'*long_img);
long_meas=meas_udisk(long_img);
disk=.9*udisk(200);
dimg=cauchy(disk,long_img,long);

clg;
subplot(2,2,1),plot(long,'*'),title(['Hevosenkenk�']);
subplot(2,2,2),plot(long_img,'*'),title(['Kuva yksikk�kiekolla']);
subplot(2,2,3),plot(long_meas,'-'),title(['Harmoninen mitta']);
subplot(2,2,4),plot(long,'*',dimg,'*'),title(['D(0;.9):n kuva']);
