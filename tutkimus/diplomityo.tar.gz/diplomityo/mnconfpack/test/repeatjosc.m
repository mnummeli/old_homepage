function repeatjosc(p,p1,p2,p3,p4,n,step)
    pp=p;
    for k=1:n
        pp=josc(pp,step);
        M=qm(pp,p1,p2,p3,p4);
        fprintf('M=%17.15f\n',M);
    end
end
