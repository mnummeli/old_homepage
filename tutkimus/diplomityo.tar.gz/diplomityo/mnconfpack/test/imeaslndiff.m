function w=imeaslndiff(zdata,wdata)
% Mikko Nummelin, 2007

    w=zeros(1,length(zdata));
    for k=1:length(zdata)
        if k==1
            dzdata=zdata(2)-zdata(length(zdata));
            dwdata=wdata(2)-wdata(length(wdata));
        elseif k==length(zdata)
            dzdata=zdata(1)-zdata(length(zdata)-1);
            dwdata=wdata(1)-wdata(length(wdata)-1);
        else
            dzdata=zdata(k+1)-zdata(k-1);
            dwdata=wdata(k+1)-wdata(k-1);
        end
        if k>2
            w(k)=w(k-1)+dwdata/(dzdata*wdata(k));
        else
            w(k)=dwdata/(dzdata*wdata(k));
        end
    end
end
