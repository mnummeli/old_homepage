1;

fop=fopen('test_gaier3_josc.dat','w');
p=polygon([0,2,2+i,1+i,1+2i,2i],2000);
p=p-(.7+.7i);

fprintf(fop,'\\begin{center}\n');
fprintf(fop,'\\begin{tabular}{c|c|c}\n');
fprintf(fop,'$n$ & $M$ & virhe \\\\\n');
fprintf(fop,'\\hline\n');

prev_k=0;
pp=p;

for k=[10,20,30,50,100,200,300,500,1000,2000]
    pp=josc(pp,k-prev_k);
    M=qm(pp,4001,8001,10001,1);
    fprintf(fop,'%5d & %8.6f & %e',k,M,...
        abs(0.585080-M));
    if k<2000
        fprintf(fop,' \\\\');
    end
    fprintf(fop,'\n');
    prev_k=k;
end
fprintf(fop,'\\end{tabular}\n');
fprintf(fop,'\\end{center}\n');
fclose(fop);
