function export_linedata(ca,label,filename)
	len=length(ca);
	fop=fopen(filename,'a');
	fprintf(fop,['path ',label,'[];\n']);
	for k=1:len
		fprintf(fop,[label,'%d='],k);
		ldata=ca{k};
		for k2=1:length(ldata)
			if k2<length(ldata)
				fprintf(fop,'(%fu,%fu)..',real(ldata(k2)),...
				imag(ldata(k2)));
			else
				fprintf(fop,'(%fu,%fu);\n',real(ldata(k2)),...
				imag(ldata(k2)));
			end
		end
	end
	fprintf(fop,'\n');
	fclose(fop);
end
