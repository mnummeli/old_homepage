1;

p=eqpolygon([0,3,3-2i,6-2i,6-i,4-i,4,6,6+i,i]);
p1=p-(3.5+.5i);
p2=convex_angleosc(p1,2);
plot(p2,'*');pause;
p3=angleosc(p2,3);
plot(p3,'*');pause;
p4=josc(p3,100);
p4=force_to_udisk(p4);
c=cauchy(0,p1,p4);
plot(p4,'-',c,'+');pause;
p5=(p4-c)./(1-c'*p4);
p5pt=p5(901);
p5=p5*p5pt';
plot(p5,'*');
disk=.9*udisk(1000);
diskimg=cauchy(disk,p5,p);
plot(p,'-',diskimg,'-');
p5meas=meas_udisk(p5);
uline=drawline(0,.9,90);
ulineimg=cauchy(uline,p5,p);

% Laadittava rutiini, joka laskee p:lle sellaisen konformikuvan
% yksikkökiekolle, jossa pimg(901) on oikealla ja jossa on määritelty
% haluttu konformikeskus.
