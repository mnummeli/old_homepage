1;

fop=fopen('test_p3_josc2.dat','w');
p3=polygon([0,1,1+i,2i],5000); % 20000 reunapistett�
p3=p3-(.5+.5i);

fprintf(fop,'\\begin{center}\n');
fprintf(fop,'\\begin{tabular}{c|c|c}\n');
fprintf(fop,'$n$ & $M$ & virhe \\\\\n');
fprintf(fop,'\\hline\n');
for k=[10,20,30,50,100,200,300,500,1000]
    pp=josc(p3,k);
    M=qm(pp,1,5001,10001,15001);
    fprintf(fop,'%5d & %8.6f & %8.6f',k,M,abs(1.2792616-M));
    if k<1000
        fprintf(fop,' \\\\');
    end
    fprintf(fop,'\n');
end
fprintf(fop,'\\end{tabular}\n');
fprintf(fop,'\\end{center}\n');
fclose(fop);
