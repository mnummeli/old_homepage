1;

horiz=-2:.2:2;
vert=1e-10:.2:4+1e-10;
z=cell(1,0);

for k1=vert
    tmp=[];
    for k2=horiz
        val=k1*i+k2;
        tmp=[tmp,asin(val)];
    end
    z{length(z)+1}=tmp;
end

for k1=horiz
    tmp=[];
    for k2=vert
        val=k1+k2*i;
        tmp=[tmp,asin(val)];
    end
    z{length(z)+1}=tmp;
end
