1;

fop=fopen('test_p2_koebe.dat','w');
p1=polygon([0,4,4+6i,6i],2500); % 10000 reunapistett�
p1=p1-(2+3i);

fprintf(fop,'\\begin{center}\n');
fprintf(fop,'\\begin{tabular}{c|c|c}\n');
fprintf(fop,'$n$ & $M$ & virhe \\\\\n');
fprintf(fop,'\\hline\n');
prev_k=0;
pp=p1;
for k=[10,20,30,50,100,200,300,500,1000,2000]
    pp=koebe(pp,k-prev_k);
    M=qm(pp,1251,3751,6251,8751);
    fprintf(fop,'%5d & %8.6f & %e',k,M,abs(1-M));
    if k<2000
        fprintf(fop,' \\\\');
    end
    fprintf(fop,'\n');
    prev_k=k;
end
fprintf(fop,'\\end{tabular}\n');
fprintf(fop,'\\end{center}\n');
fclose(fop);
