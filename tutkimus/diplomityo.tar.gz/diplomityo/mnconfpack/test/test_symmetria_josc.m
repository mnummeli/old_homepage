1;

fop=fopen('test_symmetria_josc.dat','w');
p=polygon([1,3,3+2i,2+2i,2+3i,3i,i,1+i],1250);
p=p-(1.5+1.5i);

fprintf(fop,'\\begin{center}\n');
fprintf(fop,'\\begin{tabular}{c|c|c}\n');
fprintf(fop,'$n$ & $M$ & virhe \\\\\n');
fprintf(fop,'\\hline\n');
prev_k=0;
pp=p;
for k=[10,20,30,50,100,200,300,500,1000,2000]
    pp=josc(pp,k);
    M=qm(pp,1251,3751,6251,8751);
    fprintf(fop,'%5d & %8.6f & %e',k,M,abs(1-M));
    if k<2000
        fprintf(fop,' \\\\');
    end
    fprintf(fop,'\n');
end
fprintf(fop,'\\end{tabular}\n');
fprintf(fop,'\\end{center}\n');
fclose(fop);
