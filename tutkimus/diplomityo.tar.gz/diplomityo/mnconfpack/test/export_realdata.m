function export_realdata(vertices,label,filename,xscale)
    if nargin<4
        xscale=.01;
    end

    fop=fopen(filename,'a');
    fprintf(fop,'%s=',label);
    for k=1:length(vertices)-1
        fprintf(fop,'(%fu,%fu)--',k/xscale,real(vertices(k)));
    end
    k=length(vertices);
    fprintf(fop,'(%fu,%fu);',k/xscale,real(vertices(k)));
    fclose(fop);
end
