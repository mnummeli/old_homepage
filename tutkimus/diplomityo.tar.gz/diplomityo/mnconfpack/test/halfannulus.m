1;

z=cell(1,0);

for k1=0:.1:.4
    tmp=[];
    for k2=0:.1:2
        tmp=[tmp,k1+i*k2];
    end
    z{length(z)+1}=exp(pi*tmp/2);
end

for k2=0:.1:2
    tmp=[];
    for k1=0:.1:.4
        tmp=[tmp,k1+i*k2];
    end
    z{length(z)+1}=exp(pi*tmp/2);
end
