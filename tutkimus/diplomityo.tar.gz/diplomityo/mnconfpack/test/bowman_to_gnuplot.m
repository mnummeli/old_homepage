1;

% Constructs Bowman quadrilateral
bowmanp=eqpolygon([0,1,1+i,2i]);
bowmanp=bowmanp-(.4+.8i);

% Exports it to GNUPLOT
fop=fopen('bowmanp.dat','w');
for k=1:length(bowmanp)
    fprintf(fop,'%f %f\n',real(bowmanp(k)),imag(bowmanp(k)));
end
fclose(fop);

% Constructs an image of Bowman quadrilateral onto unit
% disk, having conformal center in the origin (original .4+.8i).
bowmanp_img=josc(bowmanp,1000);
bowmanp_img=force_to_udisk(bowmanp_img);
c=cauchy(0,bowmanp,bowmanp_img);
bowmanp_img=(bowmanp_img-c)./(1-c'*bowmanp_img);

% Constructs harmonic measure and exports it to GNUPLOT
bowmanp_meas=meas_udisk(bowmanp_img);
bowmanp_meas=bowmanp_meas*length(bowmanp_meas)/(4*pi*pi);
fop=fopen('bowmanp_meas.dat','w');
for k=1:length(bowmanp_meas)
    fprintf(fop,'%f %f\n',(2*pi*k-pi*length(bowmanp_meas))/...
        length(bowmanp_meas),bowmanp_meas(k));
end
fclose(fop);
