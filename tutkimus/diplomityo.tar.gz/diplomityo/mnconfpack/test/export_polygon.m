function export_polygon(vertices,label,filename)
    fop=fopen(filename,'a');
    fprintf(fop,'%s=',label);
    for k=1:length(vertices)
        fprintf(fop,'(%fu,%fu)--',real(vertices(k)),imag(vertices(k)));
    end
    fprintf(fop,'cycle;');
    fclose(fop);
end
