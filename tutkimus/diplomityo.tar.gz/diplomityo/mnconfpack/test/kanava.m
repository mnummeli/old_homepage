1;

horiz=-5:.2:5;
vert=-pi/4:pi/16:pi/4;
z=cell(1,0);

for k1=vert
    tmp=[];
    for k2=horiz
        val=k1*i+k2;
        tmp=[tmp,tanh(val)];
    end
    z{length(z)+1}=tmp;
end

for k1=horiz
    tmp=[];
    for k2=vert
        val=k1+k2*i;
        tmp=[tmp,tanh(val)];
    end
    z{length(z)+1}=tmp;
end
