1;

p10=polygon([0,7,7+3i,7+4i,7+5i,7+9i,9i,2i,2+2i,2+3i,1+3i,1+6i,5+6i,5+7i,...
    1+7i,2+8i,6+8i,6+5i,5+5i,4+5i,3+5i,2+5i,2+4i,3+4i,3+3i,4+3i,4+4i,5+4i,...
    6+3i,5+3i,5+2i,6+2i,5+i,4+i,4+2i,3+2i,3+i,i],100);
disk=.8*udisk(100);
labs=cell(4);
lab_imgs=cell(4);
lab_meas=cell(4);
lab_disks=cell(4);
labs{1}=p10-(2.5+4.5i);
labs{2}=p10-(3.5+4i);
labs{3}=p10-(4.5+4.5i);
labs{4}=p10-(6+4i);
for k=1:4
    lab_imgs{k}=koebe(labs{k},1000);
    lab_meas{k}=meas_udisk(lab_imgs{k});
    lab_disks{k}=cauchy(disk,lab_imgs{k},p10);
    fprintf('Labyrintti %d ok.\n',k);
end
