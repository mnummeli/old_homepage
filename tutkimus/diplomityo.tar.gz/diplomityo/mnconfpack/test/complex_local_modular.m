function w=complex_local_modular(z)
% Mittaa Jordan-käyrän z reunaominaisuuksia vetämällä käyrän
% 3 seuraavaa pistettä Möbius-kuvauksella pisteisiin
% 0,1,Inf ja tallentamalla mainitun pisteen kuvan.

% Mikko Nummelin, 2007

    len=length(z);
    w=zeros(1,len);
    for k=0:len-1
        curr=z(k+1);
        n1=z(mod(k+1,len)+1);
        n2=z(mod(k+2,len)+1);
        n3=z(mod(k+3,len)+1);
        w(k+1)=(n2-n3)*(curr-n1)/((n2-n1)*(curr-n3));
    end
end
