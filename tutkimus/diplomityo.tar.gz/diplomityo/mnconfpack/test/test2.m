1;

p=polygon([0,2,1+i,i]);
pp=p-(.8+.6i);
ptoudisk=josc(pp,1000);
z=[];
for k1=.1:.1:1.9
    for k2=.1:.1:.9
        if k1+k2<2
            z=[z,k1+k2*i];
        end
    end
end
ztoudisk=cauchy(z,p,ptoudisk);
