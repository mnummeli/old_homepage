1;

p=polygon([0,2,1+i,i]);
p=p-(.8+.6i);
plot(p,'*');pause;
p2=josc(p,1000);
disk=.95*udisk(100);
diskimg=cauchy(disk,p2,p);
plot(diskimg,'*');
