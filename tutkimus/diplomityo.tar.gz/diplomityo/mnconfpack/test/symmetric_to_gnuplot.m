1;

% Constructs symmetric polygon
symmp=eqpolygon([-1-i,-1-3i,3-3i,3+i,1+i,1+3i,-3+3i,-3-i]);

% Exports it to GNUPLOT
fop=fopen('symmp.dat','w');
for k=1:length(symmp)
    fprintf(fop,'%f %f\n',real(symmp(k)),imag(symmp(k)));
end
fclose(fop);

% Constructs an image of symmetric polygon onto unit
% disk, having conformal center in the origin.
symmp_img=angleosc(symmp,2);
symmp_img=josc(symmp,1000);
symmp_img=force_to_udisk(symmp_img);
c=cauchy(0,symmp,symmp_img);
symmp_img=(symmp_img-c)./(1-c'*symmp_img);

% Constructs harmonic measure and exports it to GNUPLOT
symmp_meas=meas_udisk(symmp_img);
symmp_meas=symmp_meas*length(symmp_meas)/(4*pi*pi);
fop=fopen('symmp_meas.dat','w');
for k=1:length(symmp_meas)
    fprintf(fop,'%f %f\n',(2*pi*k-pi*length(symmp_meas))/...
        length(symmp_meas),symmp_meas(k));
end
fclose(fop);
