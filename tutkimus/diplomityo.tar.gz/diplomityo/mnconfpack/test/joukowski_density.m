1;

fop=fopen('joukowskidensity.ppm','w');
fprintf(fop,'P3\n200 100\n255\n');

for k1=0:99
    for k2=0:199
        z=-2+k2/50+i*(1-k1/50);
        val=abs(1-1/(z*z));
        if val==0
            skew=-Inf;
        elseif val==Inf
            skew=Inf;
        else
            skew=log(val)/log(10);
        end
        if skew==0
            fprintf(fop,'0 255 0\n');
        elseif skew>=1
            fprintf(fop,'255 0 0\n');
        elseif skew<=-1
            fprintf(fop,'0 0 255\n');
        elseif skew>0.5
            sval=skew*255;
            fprintf(fop,'255 %d 0\n',255-round(sval));
        elseif skew>0
            sval=skew*255;
            fprintf(fop,'%d 255 0\n',round(sval));
        elseif skew<-0.5
            sval=-skew*255;
            fprintf(fop,'0 %d 255\n',255-round(sval));
        else
            sval=-skew*255;
            fprintf(fop,'0 255 %d\n',round(sval));
        end
    end
end

fclose(fop);
