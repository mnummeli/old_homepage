1;

% Constructs symmetric polygon
symmp=eqpolygon([-1-i,-1-3i,3-3i,3+i,1+i,1+3i,-3+3i,-3-i]);

% Constructs an image of symmetric polygon onto unit
% disk, having conformal center out from origin.
symmp=symmp-(1-i);
symmp_img=angleosc(symmp,2);
symmp_img=josc(symmp_img,1000);
symmp_img=force_to_udisk(symmp_img);
c=cauchy(0,symmp,symmp_img);
symmp_img=(symmp_img-c)./(1-c'*symmp_img);

% Constructs harmonic measure and exports it to GNUPLOT
symmp_meas=meas_udisk(symmp_img);
symmp_meas=symmp_meas*length(symmp_meas)/(4*pi*pi);
fop=fopen('symmp2_meas.dat','w');
for k=1:length(symmp_meas)
    fprintf(fop,'%f %f\n',(2*pi*k-pi*length(symmp_meas))/...
        length(symmp_meas),symmp_meas(k));
end
fclose(fop);
