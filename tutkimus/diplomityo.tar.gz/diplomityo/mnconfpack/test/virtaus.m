1;

horiz=-3:.2:3;
vert=0:.2:2;
z=cell(1,0);

for k1=vert
    tmp=[];
    for k2=horiz
        val=k1*i+k2;
        if real(val)<-1 && imag(val)==0
            tmp=[tmp,-sqrt(val*val-1)];
        else
            tmp=[tmp,usqrt(val*val-1)];
        end
    end
    z{length(z)+1}=tmp;
end

for k1=horiz
    tmp=[];
    for k2=vert
        val=k1+k2*i;
        if real(val)<-1 && imag(val)==0
            tmp=[tmp,-sqrt(val*val-1)];
        else
            tmp=[tmp,usqrt(val*val-1)];
        end
    end
    z{length(z)+1}=tmp;
end
