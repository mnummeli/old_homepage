1;

fop=fopen('test_minilab_multi.dat','w');
p=polygon([0,5,5+5i,5i,2i,3+2i,3+3i,1+3i,1+4i,4+4i,4+i,i],1000);
p=p-(.75+4.25i);

fprintf(fop,'\\begin{center}\n');
fprintf(fop,'\\begin{tabular}{c|c|c}\n');
fprintf(fop,'$n$ & $M$ & virhe\\\\\n');
fprintf(fop,'\\hline\n');
prev_k=0;
pp=convex_angleosc(p);
for k=[10,20,30,50,100,200,300,500,1000,2000,3000,5000,10000]
    pp=koebe(pp,k-prev_k);
    M=qm(pp,5001,6001,11001,1);
    fprintf(fop,'%5d & %f & %e',k,M,abs(15.7114-M));
    if k<10000
        fprintf(fop,' \\\\');
    end
    fprintf(fop,'\n');
    prev_k=k;
end
fprintf(fop,'\\end{tabular}\n');
fprintf(fop,'\\end{center}\n');
fclose(fop);
