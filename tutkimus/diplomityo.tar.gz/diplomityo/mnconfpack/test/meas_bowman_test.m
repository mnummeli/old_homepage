1;

bowman=eqpolygon([-1-.5i,1-.5i,.5i,-1+.5i],50);
bowman_img=josc(bowman,300);
v=cauchy(0,bowman,bowman_img);
bowman_img=(bowman_img-v)./(1-v'*bowman_img);
bowman_meas=meas_udisk(bowman_img);
disk=.9*udisk(200);
dimg=cauchy(disk,bowman_img,bowman);

%__gnuplot_set__ terminal postscript
clg;
subplot(2,2,1),plot(bowman,'*'),title(['Bowmanin nelikulmio']);
subplot(2,2,2),plot(bowman_img,'*'),title(['Kuva yksikk�kiekolla']);
subplot(2,2,3),plot(bowman_meas,'-'),title(['Kasautumat']);
subplot(2,2,4),plot(bowman,'*',dimg,'*'),title(['D(0;.9):n kuva']);
