1;

square=eqpolygon([1,1+i,-1+i,-1-i,1-i],25);
square_img=josc(square,300);
v=cauchy(0,square,square_img);
square_img=(square_img-v)./(1-v'*square_img);
square_meas=meas_udisk(square_img);
disk=.9*udisk(200);
dimg=cauchy(disk,square_img,square);

%__gnuplot_set__ terminal postscript
clg;
subplot(2,2,1),plot(square,'*'),title(['Neli�']);
subplot(2,2,2),plot(square_img,'*'),title(['Kuva yksikk�kiekolla']);
subplot(2,2,3),plot(square_meas,'-'),title(['Kasautumat']);
subplot(2,2,4),plot(dimg,'-'),title(['D(0;.9):n kuva']);
