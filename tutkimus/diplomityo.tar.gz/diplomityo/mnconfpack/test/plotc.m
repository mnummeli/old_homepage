function plotc(ca)
	for k=1:length(ca)
		plot(ca{k},'*');pause;
	end
end
