% TESTDATA2.M (t�m� versio vain generoi monikulmiot)
%
% Monikulmiotestidataa diplomity�ss� k�ytettyjen konformikuvausmenetelmien
% testaamista varten. Algoritmien p��asiallinen keskin�isen paremmuuden
% mittari on sen laskema yleistetyn nelikulmion modulin arvo ja t�m�n
% tarkkuus. T�ss� tiedostossa monikulmiot on annettu Tobin A. Driscollin
% Schwarz-Christoffel Toolbox:in ymm�rt�m�ss� muodossa, mink� perusteella
% on my�s viitearvot konformiselle modulille saatu. Kulmien indeksit on
% ilmaistu periaatteella: vastap�iv��n, ''pitk� sivu'' ensin.
%
% Mikko Nummelin, 2007

% Monikulmio 1. (Suorakaide)

p1=polygon([0,2,4,4+3i,4+6i,2+6i,6i,3i]);
%f1=rectmap(p1,[8,2,4,6]);

% Moduli:
%     Teoreettinen: 1
%     SC:           1

% Monikulmio 2. (Suorakaiteen automorfismi, symmetria)

p2=polygon([0,4,4+6i,6i]);
%f2=rectmap(p2,[4,1,2,3]);

% Moduli:
%     Teoreettinen: 1.5
%     SC:           1.5

% Monikulmio 3. (Symmetria)

p3=polygon([1,3,3+2i,2+2i,2+3i,3i,i,1+i]);
%f3=rectmap(p3,[2,4,6,8]);

% Moduli:
%     Teoreettinen: 1
%     SC:           1

% Monikulmio 4. (�ss�)

p4=polygon([1,2,3+i,2+2i,1+2i,2+3i,1+3i,2i,1+i,2+i]);
%f4=rectmap(p4,[6,10,1,5]);

% Moduli:
%     SC: 2.8759782

% Monikulmio 5. (Hevosenkenk�)

p5=polygon([0,3,3+i,1+i,1+2i,3+2i,3+3i,3i]);
%f5=rectmap(p5,[7,2,3,6]);

% Moduli:
%     SC: 6.112652

% Monikulmio 6. (Bowmanin nelikulmio)

p6=polygon([0,2,1+i,i]);
%f6=rectmap(p6,[1,2,3,4]);

% Moduli:
%     SC: 1.2792616

% Monikulmio 7. (Minilabyrintti)

p7=polygon([0,5,5+5i,5i,2i,3+2i,3+3i,1+3i,1+4i,4+4i,4+i,i]);
%f7=rectmap(p7,[4,1,2,3]);

% Moduli:
%     SC: 4.4412699

% Monikulmio 8. (Minilabyrintti, automorfismi)

%f8=rectmap(p7,[7,12,1,6]);

% Moduli:
%     SC: 15.230092

% Monikulmio 9. (T�hti)

tmp=test9();
p9=polygon(tmp);
%f9=rectmap(p9,[1,2,3,4]);

% Moduli:
%     Teoreettinen: 1
%     SC:           (ei toimi)

% Monikulmio 10. (Labyrintti)

p10=polygon([0,7,7+9i,9i,2i,2+2i,2+3i,1+3i,1+6i,5+6i,5+7i,...
    1+7i,2+8i,6+8i,6+5i,2+5i,2+4i,3+4i,3+3i,4+3i,4+4i,5+4i,...
    6+3i,5+3i,5+2i,6+2i,5+i,4+i,4+2i,3+2i,3+i,i]);
%f10=rectmap(p10,[1,6,7,32]);

% Moduli:
%     SC: (ei toimi)

% Monikulmio 11. (Gaierin L)

p11=polygon([0,2,2+i,1+i,1+2i,2i]);
% f11=rectmap(p11,[6,1,2,3]);

% Moduli:
%     Gaier: 0.577350
%     SC:    0.57735028

% Monikulmio 12. (Gaierin L)
% f12=rectmap(p11,[5,6,1,3]);

% Moduli:
%     Gaier: 0.585080
%     SC:    0.5850797

% Monikulmio 13. (Gaierin L)

p13=polygon([0,1,2,2+i,1+i,1+2i,2i]);
% f13=rectmap(p13,[6,2,4,5]);

% Moduli:
%     Gaier: 1.279262
%     SC:    1.2792616

% Monikulmio 14. (Gaier-Bowman)

p14=polygon([0,2,2+i,1.5+1.5i]);
% f14=rectmap(p14,[4,1,2,3]);

% Moduli:
%     Gaier: 1.205
%     SC:    1.2052604
