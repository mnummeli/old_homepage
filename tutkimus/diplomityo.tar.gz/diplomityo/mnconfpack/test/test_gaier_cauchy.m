1;

z=polygon([0,1,2,2+i,1.5+i,1+i,1+1.5i,1+2i,2i,i],200);
z=z-(.8+.8i);

inz=[];
for k1=.1:.1:1.9
    for k2=.1:.1:1.9
        if k1<1 || k2<1
            inz=[inz,k1+k2*i];
        end
    end
end
inz=inz-(.8+.8i);

fprintf('Conformally welding ...\n');
fflush(stdout);
w=koebe(z,1);
w=josc(w,300);

fprintf('Cauchy-integrating ...\n');
fflush(stdout);
inw=cauchy(inz,z,w);
