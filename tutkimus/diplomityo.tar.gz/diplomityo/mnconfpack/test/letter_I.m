1;

p=polygon([0,3,3+i,2+i,2+2i,3+2i,3+3i,3i,2i,1+2i,1+i,i]);
p2=p-(1.5+1.5i);
p3=convex_angleosc(p2);
p3=angleosc(p3);
p3=josc(p3,3000);

%z=[];
%for k=1:100:1101
%    z=[z,drawline(0,p3(k),100)];
%end
%zimg=cauchy(z,p3,p);

p4=polygon([1.1+.1i,1.9+.1i,1.9+2.9i,1.1+2.9i]);