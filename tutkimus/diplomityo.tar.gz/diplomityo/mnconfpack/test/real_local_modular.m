function w=real_local_modular(z)
% Suorittaa ensin complex_local_modular:in, ja pyrkii hakemaan
% Teichmüllerin modulaarista s:ää tilanteessa, jossa neljä
% pistettä on oletetun sulkeuma-alueen reunalla.

    w=complex_local_modular(z);
    for k=1:length(w)
        argw=imag(log(w(k)));
        if argw<0
            argw=argw+2*pi;
        end
        w(k)=abs(w(k))^(argw/pi);
    end
end
