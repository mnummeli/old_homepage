1;

load 'triangles.dat';
triangle_img=force_to_udisk(triangle_img);
c=cauchy(0,triangle,triangle_img);
triangle_img=(triangle_img-c)./(1-c'*triangle_img);
z=[];
for k=.01:.01:.99
    tmp=k*udisk(20);
    tmp_img=cauchy(tmp,triangle_img,triangle);
    z=[z,tmp_img];
    printf('%f\n',k);fflush(stdout);
end
