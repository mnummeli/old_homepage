1;

p1=polygon([1,exp(5i*pi/6),exp(7i*pi/6)]);
p2=koebe(p1,1);
p3=koebe(p1,10);
p4=josc(p1,1);
p5=josc(p1,10);
export_polygon(p1,'p1','kolmionosc.mp');
export_polygon(p2,'p2','kolmionosc.mp');
export_polygon(p3,'p3','kolmionosc.mp');
export_polygon(p4,'p4','kolmionosc.mp');
export_polygon(p5,'p5','kolmionosc.mp');
