function w=koebe(z,n)
% Mikko Nummelin, 2007

    w=z;
    mpind=maxpoint(w);
    if(abs(w(mpind))>=1)
        w=w./(abs(w(mpind))+1E-10);
    end
    for k=1:n
        mpind=minpoint(w);
        mp=w(mpind);
        rot=-mp'/abs(mp);
        w=w.*rot;
        mp=-abs(mp);
        w=(w-mp)./(1-mp*w);
        w=holsqrt(w,mpind);
        w=(w-sqrt(-mp))./(1-sqrt(-mp)*w);
        w=w*rot';
    end
end
