function w=meas_udisk(z)
% Mikko Nummelin, 2007

    angles=imag(log(z));
    angles=[angles,angles(1)];
    len=length(z);
    w=zeros(1,len);
    for k=1:len
        if angles(k+1)>angles(k)-pi
            w(k)=angles(k+1)-angles(k);
        else
            w(k)=2*pi+angles(k+1)-angles(k);
        end
    end
end
