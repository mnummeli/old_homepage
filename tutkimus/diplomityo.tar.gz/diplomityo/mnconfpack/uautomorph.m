function w=uautomorph(z,b)
% Mikko Nummelin, 2007

    w=zeros(1,length(z));
    for k1=1:length(z)
        if z(k1)==Inf || isnan(z(k1))
            w(k1)=-b;
        elseif z(k1)==b
            w(k1)=Inf;
        else
            w(k1)=z(k1)/(1-z(k1)/b);
        end
    end
end