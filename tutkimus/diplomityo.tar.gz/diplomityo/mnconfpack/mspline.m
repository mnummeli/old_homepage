function w=mspline(z,n)
    for k1=1:n
        len=length(z);
        w=[z(1),splinemean(z(len),z(1),z(2),z(3))];
        for k2=2:len-2
            w=[w,z(k2),splinemean(z(k2-1),z(k2),z(k2+1),z(k2+2))];
        end
        w=[w,z(len-1),splinemean(z(len-2),z(len-1),z(len),z(1))];
        w=[w,z(len),splinemean(z(len-1),z(len),z(1),z(2))];
        z=w;
    end
end
