function [M,polyz,polyw]=falserect(h,a,b,dens,n)
% Testiohjelma. Laatii kanonisen nelikulmion h-korkuiselle suorakaiteelle
% jossa kriittiset pisteet ovat alakulmat, oikealla sivustalla
% korkeudella a oleva piste ja vasemmalla sivustalla korkeudella
% b oleva piste ja laskee t�lle konformisen modulin Joukowskin
% muunnoksen algoritmilla.
%
% Mikko Nummelin, 2007

    if nargin<5
        n=1000;
    end
    if nargin<4
        dens=1000;
    end

    polyz=polygon([0,1,1+i*a,1+i*h,i*h,i*b],dens);
    polyw=polyz-(.5+.5i*h);
    polyw=josc(polyw,n);
    M=qm(polyw,1,dens+1,2*dens+1,5*dens+1);
end
