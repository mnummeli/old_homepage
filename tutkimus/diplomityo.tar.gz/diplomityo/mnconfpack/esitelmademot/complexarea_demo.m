% Demotiedosto pitkulaisen alueen konformikuvauksista
% Mikko Nummelin, 2007

1;

echo on;
format long;
clf;

% Laatii pitkulaisen ja haaroittuvan alueen
% tasav�lisell� pisteist�ll�
% 100 pistett� per mittayksikk�
complexarea=eqpolygon([-5-i,-1-i,-1-2i,1-4i,4-4i,6-2i,6+i,4+i,...
4-2i,1-2i,1-i,3-i,3+i,-5+i]);
plot(complexarea,'-');pause;

% Joukowskin muunnoksen algoritmi suoraan sovellettuna hajaantuu
cajosc50=josc(complexarea,50);
plot(cajosc50);pause;

% Koeben algoritmi suppenee, mutta alas muodostuu hankala kasauma
cakoebe50=koebe(complexarea,50);
plot(cakoebe50);pause;

% Suoritetaan konveksikuoren kulmienoikaisu
ca1=convex_angleosc(complexarea,3);
plot(ca1);pause;

% Ja ulkokulmien oikaisu
ca2=angleosc(ca1,4);
plot(ca2);pause;

% Nyt on helpompi edet� kun valmistellaan tilannetta Koeben
% algoritmilla ennen Joukowskin muunnoksen algoritmia.
% Varmistetaan my�s konformikeskus.
ca3=koebe(ca2,100);
ca4=josc(ca3,1000);
ca4=force_to_udisk(ca4);
c=cauchy(0,complexarea,ca4);
ca4=(ca4-c)./(1-c'*ca4);
plot(ca4,'*');pause;

% Tehd��n approksimaatio toisellakin konformikeskuksella.
complexarea2=complexarea+2;
ca21=convex_angleosc(complexarea2,3);
ca22=angleosc(ca21,4);
ca23=koebe(ca22,100);
ca24=josc(ca23,1000);
ca24=force_to_udisk(ca24);
c=cauchy(0,complexarea2,ca24);
ca24=(ca24-c)./(1-c'*ca24);
plot(ca24,'*');pause;

% Ja miksei kolmannellakin.
complexarea3=complexarea+2i;
ca31=convex_angleosc(complexarea3,3);
ca32=angleosc(ca31,4);
ca33=koebe(ca32,100);
ca34=josc(ca33,1000);
ca34=force_to_udisk(ca34);
c=cauchy(0,complexarea3,ca34);
ca34=(ca34-c)./(1-c'*ca34);
plot(ca34,'*');pause;

% Alkup. alueen ja harmonisen mitan vertailua.
disk=.9*udisk(100);
diskimg=cauchy(disk,ca4,complexarea);
diskimg2=cauchy(disk,ca24,complexarea);
diskimg3=cauchy(disk,ca34,complexarea);
complexarea_meas=meas_udisk(ca4);
complexarea2_meas=meas_udisk(ca24);
complexarea3_meas=meas_udisk(ca34);
subplot(2,2,1);
plot(complexarea);
hold on;
plot(0,0,'+');
plot(-2,0,'+');
plot(0,-2,'+');
plot(diskimg);
plot(diskimg2);
plot(diskimg3);
hold off;
subplot(2,2,2);
plot(complexarea_meas);
subplot(2,2,3);
plot(complexarea2_meas);
subplot(2,2,4);
plot(complexarea3_meas);
