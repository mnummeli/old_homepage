% Demotiedosto Bowmanin nelikulmion konformikuvauksista
% Mikko Nummelin, 2007

1;

echo on;
format long;

% Laatii Bowmanin nelikulmion tasav�lisell� pisteist�ll�
% 100 pistett� per mittayksikk�
bowmanp=eqpolygon([0,1,1+i,2i]);
bowmanp=bowmanp-(.4+.8i);
plot(bowmanp,'*');
pause;

% Askel Koeben algoritmia
bpkoebe1=koebe(bowmanp,1);
plot(bpkoebe1,'*');
pause;

% 10 askelta Koeben algoritmia
bpkoebe10=koebe(bowmanp,10);
plot(bpkoebe10,'*');
pause;

% Askel Joukowskin muunnoksen algoritmia
bpjosc1=josc(bowmanp,1);
plot(bpjosc1,'*');
pause;

% 10 askelta Joukowskin muunnoksen algoritmia
bpjosc10=josc(bowmanp,10);
plot(bpjosc10,'*');
pause;

% 300 askelta Joukowskin muunnoksen algoritmia ja reunan
% tasoitus. T�t� k�ytet��n Bowmanin nelikulmion yksikk�kiekkkokuvan
% reunan approksimaationa.
bpjosc300=josc(bowmanp,300);
bpjosc300=force_to_udisk(bpjosc300);
plot(bpjosc300,'*');
pause;

% Konformisen keskipisteen korjaus Cauchyn integraalilla ja
% yksikk�kiekon automorfismilla.
c=cauchy(0,bowmanp,bpjosc300);
bpjosc300=(bpjosc300-c)./(1-c'*bpjosc300);
plot(bpjosc300,'*');
pause;

% Nelikulmion moduli ja vertailu 10 desimaalia tarkkaan arvoon.
M=qm(bpjosc300,1,101,201,342)
Mexact=1.2792615712
fprintf('%e\n',abs(Mexact-M));
pause;

% 0.9-s�teisen ympyr�n konformikuva Bowmanin nelikulmion sis�ll�,
% alkup. konformikeskuksella.
disk=.9*udisk(100);
diskimg=cauchy(disk,bpjosc300,bowmanp);
plot(real(bowmanp),imag(bowmanp),'-',real(diskimg),imag(diskimg),'*');
pause;

% Harmoninen mitta. Kohinasta voidaan p��tell� konformikuvauksen
% virhett�.
bowmanp_meas=meas_udisk(bpjosc300);
plot(bowmanp_meas);
