function w=drawline(zstart,zend,npoints)
    t=0:1/npoints:(npoints-1)/npoints;
    w=zstart+(zend-zstart)*t;
end
