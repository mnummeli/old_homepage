function w=mobius_from_to_points(z,z0,z1,zinf,w0,w1,winf)
    w=mobius_from_points(z,z0,z1,zinf);
    w=mobius_to_points(w,w0,w1,winf);
end
