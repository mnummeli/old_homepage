function w=cauchy_vec(z,zdata,wdata,n)
% Mikko Nummelin, 2007

    if length(zdata)~=length(wdata)
        error('zdata and wdata should have equal length.');
    end
    if nargin<4
        n=0;
    end

    wdata2=wdata./(zdata-z).^(n+1);
    w=zeros(1,length(zdata));
    for k1=1:length(zdata)
        if k1>1
            dzdata=zdata(k1)-zdata(k1-1);
            wval=(wdata2(k1)+wdata2(k1-1))/2;
        else
            dzdata=zdata(1)-zdata(length(zdata));
            wval=(wdata2(1)+wdata2(length(wdata)))/2;
        end
        w(k1)=wval*dzdata;
    end
end
