function w=josc(z,n)
% Mikko Nummelin, 2007

    w=z;
    mpind=maxpoint(w);
    if(abs(w(mpind))>=1)
        w=w./(abs(w(mpind))+1E-10);
    end
    for k=1:n
        mpind=minpoint(w);
        mp=w(mpind);
        rot=mp'/abs(mp);
        w=w.*rot;
        mp=abs(mp);
        alpha=(mp-1)*(mp-1)/2;
        w=w-alpha./(w-1);
        w=w.*rot';
        mpind=maxpoint(w);
        w=w./(abs(w(mpind))+1E-10);
    end
end
