function [k,val]=maxpoint(z)
% Mikko Nummelin, 2007

    k=1;val=abs(z(1));
    for k1=2:length(z)
        if(abs(z(k1))>val)
            k=k1;
            val=abs(z(k));
        end
    end
end
