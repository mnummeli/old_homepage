function w=ncpolygon(v,n)
% Mikko Nummelin, 2007

    if nargin<2
        n=100;
    end
    w=[];
    for k=1:length(v)
        curr=v(k);
        if k<length(v)
            next=v(k+1);
        else
            next=v(1);
        end
        for k2=0:n-1
            tmp=polyval([4,-6,3,0],k2/n);
            w=[w,curr+(next-curr)*tmp];
        end
    end
end
