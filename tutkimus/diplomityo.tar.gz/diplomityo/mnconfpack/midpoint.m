function w=midpoint(z)
    w=0;
    for k=1:length(z)
        w=w+z(k);
    end
    w=w/length(z);
end
