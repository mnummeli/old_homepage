function m=qm(z,zll,zlr,zur,zul)
% Mikko Nummelin, 2007

    s=modular_s(z,zll,zlr,zur,zul);
    m=ellipke(1-1/s)/ellipke(1/s);
end