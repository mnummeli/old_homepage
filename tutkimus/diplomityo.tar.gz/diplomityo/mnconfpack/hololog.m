function w=hololog(z,k)
% Mikko Nummelin, 2007

    if nargin<2
        k=1;
    end
    w=zeros(1,length(z));
    br=0;p=0;
    if k<length(z)
        for k1=k+1:length(z)
            s=log(z(k1))+2*i*pi*br;
            if abs(s-p)>abs(s+2*i*pi-p)
                w(k1)=s+2*i*pi;
                p=s+2*i*pi;
                br=br+1;
            elseif abs(s-p)>abs(s-2*i*pi-p)
                w(k1)=s-2*i*pi;
                p=s-2*i*pi;
                br=br-1;
            else
                w(k1)=s;
                p=s;
            end
        end
    end
    if k>1
        for k1=1:k-1
            s=log(z(k1))+2*i*pi*br;
            if abs(s-p)>abs(s+2*i*pi-p)
                w(k1)=s+2*i*pi;
                p=s+2*i*pi;
                br=br+1;
            elseif abs(s-p)>abs(s-2*i*pi-p)
                w(k1)=s-2*i*pi;
                p=s-2*i*pi;
                br=br-1;
            else
                w(k1)=s;
                p=s;
            end
        end
    end
end
