function [w,rb1,rb2]=geodesic(z,k)
% Mikko Nummelin, 2007

    len=length(z);
    if nargin<2
        k=len;
    end

    w=z;
    rb1=zeros(1,len);
    rb2=zeros(1,len);
    rb1(1)=NaN;
    rb2(1)=NaN;
    w(3:len)=(z(3:len)-z(2))./(z(3:len)-z(1));
    w(3:len)=i*sqrt(w(3:len));
    for k1=3:k
        b2=abs(w(k1)*w(k1))/imag(w(k1));
        b2=b2*b2;
        if real(w(k1))~=0
            b=abs(w(k1))*abs(w(k1))/real(w(k1));
            rb1(1:k1-1)=uautomorph(rb1(1:k1-1),b);
            rb2(1:k1-1)=uautomorph(rb2(1:k1-1),b);
            w(k1:len)=uautomorph(w(k1:len),b);
        end
        rb1(1:k1-1)=rb1(1:k1-1).*rb1(1:k1-1)+b2;
        rb2(1:k1-1)=rb2(1:k1-1).*rb2(1:k1-1)+b2;
        w(k1:len)=w(k1:len).*w(k1:len)+b2;
        rb1(1:k1-1)=sqrt(rb1(1:k1-1));
        rb2(1:k1-1)=-sqrt(rb2(1:k1-1));
        if k1<len
            w(k1+1:len)=usqrt(w(k1+1:len));
        end
    end
end
