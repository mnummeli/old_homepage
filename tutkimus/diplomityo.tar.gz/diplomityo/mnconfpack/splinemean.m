function y=splinemean(x1,x2,x3,x4)
    y=(-x1+9*x2+9*x3-x4)/16;
end
