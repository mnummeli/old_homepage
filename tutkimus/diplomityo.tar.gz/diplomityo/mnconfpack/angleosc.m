function w=angleosc(z,n)
% Mikko Nummelin, 2007

    if nargin<2
        n=1000;
    end
    w=z;
    mpind=maxpoint(w);
    if(abs(w(mpind))>=1)
        w=w./(abs(w(mpind))+1E-10);
    end
    for k=1:n
        [mpind,fold]=outerangle(w);
        if fold>16/17;
            return;
        end
        mp=w(mpind);
        w=(w-mp)./(1-mp'*w);
        w2=holsqrt(w,mpind);
        oimg1=sqrt(-mp);
        oimg2=cauchy(-mp,w,w2);
        if abs(oimg1-oimg2)>abs(oimg1+oimg2)
            oimg1=-oimg1;
        end
        w=(w2-oimg1)./(1-oimg1'*w2);
    end
end
