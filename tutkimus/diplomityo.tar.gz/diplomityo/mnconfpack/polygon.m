function w=polygon(v,n)
% Mikko Nummelin, 2007

    if nargin<2
        n=100;
    end
    w=[];
    for k=1:length(v)
        curr=v(k);
        if k<length(v)
            next=v(k+1);
        else
            next=v(1);
        end
        for k2=0:n-1
            w=[w,curr+(next-curr)*k2/n];
        end
    end
end
