function s=modular_s(z,zll,zlr,zur,zul)
% Mikko Nummelin, 2007

    if z(zll)==Inf
        s=(z(zlr)-z(zul))/(z(zur)-z(zul));
    elseif z(zlr)==Inf
        s=(z(zur)-z(zll))/(z(zur)-z(zul));
    elseif z(zur)==Inf
        s=(z(zlr)-z(zul))/(z(zlr)-z(zll));
    elseif z(zul)==Inf
        s=(z(zur)-z(zll))/(z(zlr)-z(zll));
    else
        s=(z(zlr)-z(zul))*(z(zur)-z(zll))/...
            ((z(zlr)-z(zll))*(z(zur)-z(zul)));
    end
    s=real(s);
end
