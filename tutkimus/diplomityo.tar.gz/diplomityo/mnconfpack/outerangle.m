function [k,n]=outerangle(z)
% Mikko Nummelin, 2007

    k=0;max_ang=0;
    for k1=1:length(z)
        if k1==1
            prev=z(1)-z(length(z));
        else
            prev=z(k1)-z(k1-1);
        end
        if k1==length(z)
            next=z(1)-z(length(z));
        else
            next=z(k1+1)-z(k1);
        end
        ang=imag(log(prev/next));
        if ang>max_ang
            k=k1;
            max_ang=ang;
        end
    end
    n=pi/(pi+max_ang);
end
