function w=convex_angleosc(z,n)
% Mikko Nummelin, 2007

    if nargin<2
        n=1000;
    end
    w=z;
    mpind=maxpoint(w);
    if(abs(w(mpind))>=1)
        w=w./(abs(w(mpind))+1E-10);
    end
    for k=1:n
        [mpind,fold]=innerangle2(w);
        if fold<17/16;
            return;
        end
        mp=w(mpind);
        w=w-mp;
        w=w.^fold;
        oimg=(-mp)^fold;
        w=w-oimg;

        mpind=maxpoint(w);
        if(abs(w(mpind))>=1)
            w=w./(abs(w(mpind))+1E-10);
        end
    end
end
