function w=force_to_udisk(z)
    len=length(z);
    for k=1:len
        w(k)=z(k)/abs(z(k));
    end
end
