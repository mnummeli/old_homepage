function w=multiosc(z,m,n)
    w=angleosc(z);
    w=koebe(w,m);
    w=josc(w,n);
end
