function val=starlike(z,tol)
% Mikko Nummelin, 2007

    if nargin<2
        tol=1e-6;
    end
    val=1;
    for k=1:length(z)
        curr=z(k);
        if k<length(z)
            next=z(k+1);
        else
            next=z(1);
        end
        if real(curr)*imag(next)-real(next)*imag(curr)<-tol
            val=0;
            return;
        end
    end
end
